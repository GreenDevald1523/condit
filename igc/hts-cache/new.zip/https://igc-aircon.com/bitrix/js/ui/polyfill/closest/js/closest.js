<!DOCTYPE html>
 <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru" class="  ">
	<head>
<script>
  dataLayer = [];
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-T9WMF4Z');</script>
<!-- End Google Tag Manager -->
						<title>Ошибка: 404 - Страница не найдена - igc-aircon</title>
<meta name="yandex-verification" content="ab6667a4ab9bbd2d" />
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
		<meta name="viewport" content="initial-scale=1.0, width=device-width" />
		<meta name="HandheldFriendly" content="true" />
		<meta name="yes" content="yes" />
		<meta name="apple-mobile-web-app-status-bar-style" content="black" />
		<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="keywords" content="вентиляция, вентиляция офисов, вентиляция кафе" />
<meta name="description" content="Профессиональное проектирование и монтаж вентиляции и систем кондиционирования." />
<link href="/bitrix/js/main/core/css/core.min.css?15770776152854" rel="stylesheet" />



<link href="https://fonts.googleapis.com/css?family=Roboto:300italic,400italic,500italic,700italic,400,300,500,700subset=latin,cyrillic-ext"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/vendor/OwlCarousel2-2.3.4/dist/assets/owl.carousel.min.css?15933478613351"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/vendor/OwlCarousel2-2.3.4/dist/assets/owl.theme.default.min.css?15933478611013"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/print.min.css?159334786311298"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/animation/animate.min.css?159334786352789"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/animation/animation_ext.min.css?15933478633791"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/slick.min.css?15933478631327"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/fonts/font-awesome/css/font-awesome.min.css?159334786331000"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/jquery.fancybox.min.css?15933478633213"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/vendor/flexslider/flexslider.min.css?15933478613858"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/bootstrap.min.css?159334786388745"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/theme-elements.min.css?15933478633335"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/theme-responsive.min.css?1593347863703"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/modifiers.min.css?15933478636954"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/modifiers_responsive.css?15933478634642"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/h1-normal.css?1593347863153"  data-template-style="true"  rel="stylesheet" />
<link href="/bitrix/templates/.default/ajax/ajax.min.css?1577077615420"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/partners_1.css?16130571404818"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/width-2.min.css?15933478631245"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/font-10.min.css?15933478632373"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/jquery.mCustomScrollbar.min.css?159334786342839"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/components/bitrix/menu/top_new/style.css?16041788013651"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/styles.css?160969960022417"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/template_styles.css?16388689721016592"  data-template-style="true"  rel="stylesheet" />
<link href="/local/css/reaspekt/reaspekt.geobase/style.css?1594099293974"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/responsive.min.css?159334786382908"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/themes/CUSTOM_s2/colors.min.css?164337993729550"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/footer.css?161900114054937"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/develop.css?1593347863741"  data-template-style="true"  rel="stylesheet" />
<link href="/local/templates/centino-heat_s2/css/custom.css?16143260215982"  data-template-style="true"  rel="stylesheet" />
<script>if(!window.BX)window.BX={};if(!window.BX.message)window.BX.message=function(mess){if(typeof mess==='object'){for(let i in mess) {BX.message[i]=mess[i];} return true;}};</script>
<script>(window.BX||top.BX).message({'JS_CORE_LOADING':'Загрузка...','JS_CORE_NO_DATA':'- Нет данных -','JS_CORE_WINDOW_CLOSE':'Закрыть','JS_CORE_WINDOW_EXPAND':'Развернуть','JS_CORE_WINDOW_NARROW':'Свернуть в окно','JS_CORE_WINDOW_SAVE':'Сохранить','JS_CORE_WINDOW_CANCEL':'Отменить','JS_CORE_WINDOW_CONTINUE':'Продолжить','JS_CORE_H':'ч','JS_CORE_M':'м','JS_CORE_S':'с','JSADM_AI_HIDE_EXTRA':'Скрыть лишние','JSADM_AI_ALL_NOTIF':'Показать все','JSADM_AUTH_REQ':'Требуется авторизация!','JS_CORE_WINDOW_AUTH':'Войти','JS_CORE_IMAGE_FULL':'Полный размер'});</script>

<script src="/bitrix/js/main/core/core.min.js?1622714960252095"></script>

<script>BX.setJSList(['/bitrix/js/main/core/core_ajax.js','/bitrix/js/main/core/core_promise.js','/bitrix/js/main/polyfill/promise/js/promise.js','/bitrix/js/main/loadext/loadext.js','/bitrix/js/main/loadext/extension.js','/bitrix/js/main/polyfill/promise/js/promise.js','/bitrix/js/main/polyfill/find/js/find.js','/bitrix/js/main/polyfill/includes/js/includes.js','/bitrix/js/main/polyfill/matches/js/matches.js','/bitrix/js/ui/polyfill/closest/js/closest.js','/bitrix/js/main/polyfill/fill/main.polyfill.fill.js','/bitrix/js/main/polyfill/find/js/find.js','/bitrix/js/main/polyfill/matches/js/matches.js','/bitrix/js/main/polyfill/core/dist/polyfill.bundle.js','/bitrix/js/main/core/core.js','/bitrix/js/main/polyfill/intersectionobserver/js/intersectionobserver.js','/bitrix/js/main/lazyload/dist/lazyload.bundle.js','/bitrix/js/main/polyfill/core/dist/polyfill.bundle.js','/bitrix/js/main/parambag/dist/parambag.bundle.js']);
BX.setCSSList(['/bitrix/js/main/core/css/core.css','/bitrix/js/main/lazyload/dist/lazyload.bundle.css','/bitrix/js/main/parambag/dist/parambag.bundle.css']);</script>
<script>(window.BX||top.BX).message({'LANGUAGE_ID':'ru','FORMAT_DATE':'DD.MM.YYYY','FORMAT_DATETIME':'DD.MM.YYYY HH:MI:SS','COOKIE_PREFIX':'BITRIX_SM','SERVER_TZ_OFFSET':'10800','SITE_ID':'s2','SITE_DIR':'/','USER_ID':'','SERVER_TIME':'1653151331','USER_TZ_OFFSET':'0','USER_TZ_AUTO':'Y','bitrix_sessid':'9529e9ebc927b40cd9eea469a57879cf'});</script>


<script src="/bitrix/js/main/jquery/jquery-1.8.3.min.js?157707761593637"></script>
<script src="/bitrix/js/main/core/core.min.js?1622714960252095"></script>
<script src="/bitrix/js/main/jquery/jquery-2.1.3.min.min.js?157707761584283"></script>
<script src="/bitrix/js/main/ajax.js?157707761935509"></script>
<script>BX.setJSList(['/local/templates/centino-heat_s2/js/plax.js','/local/templates/centino-heat_s2/js/jquery.actual.min.js','/local/templates/centino-heat_s2/js/jquery.fancybox.js','/local/templates/centino-heat_s2/vendor/jquery.easing.js','/local/templates/centino-heat_s2/vendor/jquery.appear.js','/local/templates/centino-heat_s2/vendor/jquery.cookie.js','/local/templates/centino-heat_s2/vendor/jquery.validate.min.js','/local/templates/centino-heat_s2/js/jquery.uniform.min.js','/local/templates/centino-heat_s2/js/jquery-ui.min.js','/local/templates/centino-heat_s2/js/jqModal.js','/local/templates/centino-heat_s2/js/detectmobilebrowser.js','/local/templates/centino-heat_s2/vendor/flexslider/jquery.flexslider.js','/local/templates/centino-heat_s2/js/velocity.js','/local/templates/centino-heat_s2/js/velocity.ui.js','/local/templates/centino-heat_s2/vendor/bootstrap.js','/local/templates/centino-heat_s2/js/matchMedia.js','/local/templates/centino-heat_s2/js/slick.min.js','/local/templates/centino-heat_s2/vendor/OwlCarousel2-2.3.4/dist/owl.carousel.js','/local/templates/centino-heat_s2/js/jquery.alphanumeric.js','/local/templates/centino-heat_s2/js/jquery.autocomplete.js','/local/templates/centino-heat_s2/js/jquery.mobile.custom.touch.min.js','/local/templates/centino-heat_s2/js/custom.js','/local/templates/centino-heat_s2/js/general.js','/local/templates/centino-heat_s2/js/jquery.mCustomScrollbar.js','/bitrix/components/bitrix/search.title/script.js','/local/templates/centino-heat_s2/components/bitrix/search.title/fixed/script.js','/local/js/reaspekt/reaspekt.geobase/script.js','/local/templates/centino-heat_s2/js/jquery.inputmask.bundle.min.js']);</script>
<script data-skip-moving='true'>window['centinoRecaptcha'] = {params: {'recaptchaColor':'light','recaptchaLogoShow':'y','recaptchaSize':'normal','recaptchaBadge':'bottomright','recaptchaLang':'ru'},key: '6LfrDbIZAAAAAGhWjllJEe92XGctrrux1wZfHXVI'};</script>
<script data-skip-moving='true'>!function(a,e,r,c,t){function n(r){var c=e.getElementById(r);if(c&&!(c.className.indexOf("g-recaptcha")<0)&&a.grecaptcha&&!c.children.length){var n=grecaptcha.render(r,{sitekey:a[t].key+"",theme:a[t].params.recaptchaColor+"",size:a[t].params.recaptchaSize+"",callback:"onCaptchaVerify"+a[t].params.recaptchaSize,badge:a[t].params.recaptchaBadge});$(c).attr("data-widgetid",n)}}a.onLoadRenderRecaptcha=function(){for(var e in a[c].args)a[c].args.hasOwnProperty(e)&&n(a[c].args[e][0]);a[c]=function(a){n(a)}},a[c]=a[c]||function(){a[c].args=a[c].args||[],a[c].args.push(arguments),function(e,r,c){var n;e.getElementById(c)||(n=e.createElement(r),n.id=c,n.src="//www.google.com/recaptcha/api.js?hl="+a[t].params.recaptchaLang+"&onload=onLoadRenderRecaptcha&render=explicit",e.head.appendChild(n))}(e,r,"recaptchaApiLoader")}}(window,document,"script","renderRecaptchaById","centinoRecaptcha");</script>
<script data-skip-moving='true'>!function(){var e=function(e){for(var a=e;a;)if(a=a.parentNode,"form"===a.nodeName.toLowerCase())return a;return null},a=function(e){var a=[],t=null,n=!1;"undefined"!=typeof e&&(n=null!==e),t=n?e.getElementsByTagName("input"):document.getElementsByName("captcha_word");for(var r=0;r<t.length;r++)"captcha_word"===t[r].name&&a.push(t[r]);return a},t=function(e){for(var a=[],t=e.getElementsByTagName("img"),n=0;n<t.length;n++)(/\/bitrix\/tools\/captcha.php\?(captcha_code|captcha_sid)=[^>]*?/i.test(t[n].src)||"captcha"===t[n].id)&&a.push(t[n]);return a},n=function(){var t=null,n=a(t);if(0===n.length)return[];for(var r=[],c=0;c<n.length;c++){var o=e(n[c]);null!==o&&r.push(o)}return r},r=function(e){var a="recaptcha-dynamic-"+(new Date).getTime();if(null!==document.getElementById(a)){var t=!1,n=null,r=65535;do n=Math.floor(Math.random()*r),t=null!==document.getElementById(a+n);while(t);a+=n}var c=document.createElement("div");c.id=a,c.className="g-recaptcha",c.attributes["data-sitekey"]=window.centinoRecaptcha.key,e.parentNode&&(e.parentNode.className+=" recaptcha_text",e.parentNode.replaceChild(c,e)),renderRecaptchaById(a)},c=function(e){var a="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";e.attributes.src=a,e.style.display="none","src"in e&&(e.parentNode&&(e.parentNode.className+=" recaptcha_tmp_img"),e.src=a)},o=function(e){"function"==typeof $&&$(e).find(".captcha-row label > span").length&&$(e).find(".captcha-row label").html(BX.message("RECAPTCHA_TEXT")+' <span class="required-star">*</span>')},p=function(){for(var e,p=n(),d=0;d<p.length;d++){var i=p[d],l=a(i);if(0!==l.length){var s=t(i);if(0!==s.length){for(e=0;e<l.length;e++)r(l[e]);for(e=0;e<s.length;e++)c(s[e]);o(i)}}}},d=function(){if("undefined"!=typeof renderRecaptchaById)for(var e=document.getElementsByClassName("g-recaptcha"),a=0;a<e.length;a++){var t=e[a];if(0===t.innerHTML.length){var n=t.id;if("string"==typeof n&&0!==n.length){if("function"==typeof $){var r=$(t).closest(".captcha-row");r.length&&(r.addClass(window.centinoRecaptcha.params.recaptchaSize+" logo_captcha_"+window.centinoRecaptcha.params.recaptchaLogoShow+" "+window.centinoRecaptcha.params.recaptchaBadge),r.find(".captcha_image").addClass("recaptcha_tmp_img"),r.find(".captcha_input").addClass("recaptcha_text"),"invisible"!==window.centinoRecaptcha.params.recaptchaSize&&(r.find("input.recaptcha").length||$('<input type="text" class="recaptcha" value="" />').appendTo(r)))}renderRecaptchaById(n)}}}},i=function(){try{return d(),window.renderRecaptchaById&&window.centinoRecaptcha&&window.centinoRecaptcha.key?(p(),!0):(console.error("Bad captcha keys or module error"),!0)}catch(e){return console.error(e),!0}};document.addEventListener?document.addEventListener("DOMNodeInserted",i,!1):console.warn("Your browser does not support dynamic ReCaptcha replacement")}();</script>
<script>
					(function () {
						"use strict";

						var counter = function ()
						{
							var cookie = (function (name) {
								var parts = ("; " + document.cookie).split("; " + name + "=");
								if (parts.length == 2) {
									try {return JSON.parse(decodeURIComponent(parts.pop().split(";").shift()));}
									catch (e) {}
								}
							})("BITRIX_CONVERSION_CONTEXT_s2");

							if (cookie && cookie.EXPIRE >= BX.message("SERVER_TIME"))
								return;

							var request = new XMLHttpRequest();
							request.open("POST", "/bitrix/tools/conversion/ajax_counter.php", true);
							request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
							request.send(
								"SITE_ID="+encodeURIComponent("s2")+
								"&sessid="+encodeURIComponent(BX.bitrix_sessid())+
								"&HTTP_REFERER="+encodeURIComponent(document.referrer)
							);
						};

						if (window.frameRequestStart === true)
							BX.addCustomEvent("onFrameDataReceived", counter);
						else
							BX.ready(counter);
					})();
				</script>
<script>BX.message({'JS_REQUIRED':'Заполните это поле!','JS_FORMAT':'Неверный формат!','JS_FILE_EXT':'Недопустимое расширение файла!','JS_PASSWORD_COPY':'Пароли не совпадают!','JS_PASSWORD_LENGTH':'Минимум 6 символов!','JS_ERROR':'Неверно заполнено поле!','JS_FILE_SIZE':'Максимальный размер 5мб!','JS_FILE_BUTTON_NAME':'Выберите файл','JS_FILE_DEFAULT':'Файл не найден','JS_DATE':'Некорректная дата!','JS_DATETIME':'Некорректная дата/время!','JS_REQUIRED_LICENSES':'Согласитесь с условиями','S_CALLBACK':'Заказать звонок','S_QUESTION':'Задать вопрос','S_ASK_QUESTION':'Задать вопрос','ERROR_INCLUDE_MODULE_DIGITAL_TITLE':'Ошибка подключения модуля &laquo;Центино: Heat&raquo;','ERROR_INCLUDE_MODULE_DIGITAL_TEXT':'Ошибка подключения модуля &laquo;Центино: Heat&raquo;.<br />Пожалуйста установите модуль и повторите попытку','S_SERVICES':'Наши услуги','S_SERVICES_SHORT':'Услуги','S_TO_ALL_SERVICES':'Все услуги','S_CATALOG':'Каталог товаров','S_CATALOG_SHORT':'Каталог','S_TO_ALL_CATALOG':'Весь каталог','S_CATALOG_FAVORITES':'Наши товары','S_CATALOG_FAVORITES_SHORT':'Товары','S_NEWS':'Новости','S_TO_ALL_NEWS':'Все новости','S_COMPANY':'О компании','S_OTHER':'Прочее','S_CONTENT':'Контент','T_JS_ARTICLE':'Артикул: ','T_JS_NAME':'Наименование: ','T_JS_PRICE':'Цена: ','T_JS_QUANTITY':'Количество: ','T_JS_SUMM':'Сумма: ','FANCY_CLOSE':'Закрыть','FANCY_NEXT':'Вперед','FANCY_PREV':'Назад','CUSTOM_COLOR_CHOOSE':'Выбрать','CUSTOM_COLOR_CANCEL':'Отмена','S_MOBILE_MENU':'Меню','DIGITAL_T_MENU_BACK':'Назад','DIGITAL_T_MENU_CALLBACK':'Обратная связь','DIGITAL_T_MENU_CONTACTS_TITLE':'Будьте на связи','TITLE_BASKET':'В корзине товаров на #SUMM#','BASKET_SUMM':'#SUMM#','EMPTY_BASKET':'Корзина пуста','TITLE_BASKET_EMPTY':'Корзина пуста','BASKET':'Корзина','SEARCH_TITLE':'Поиск','SOCIAL_TITLE':'Оставайтесь на связи','LOGIN':'Войти','MY_CABINET':'Мой кабинет','SUBSCRIBE_TITLE':'Будьте всегда в курсе','HEADER_SCHEDULE':'Время работы','SEO_TEXT':'SEO описание','COMPANY_IMG':'Картинка компании','COMPANY_TEXT':'Описание компании','JS_RECAPTCHA_ERROR':'Пройдите проверку','JS_PROCESSING_ERROR':'Согласитесь с условиями!','CONFIG_SAVE_SUCCESS':'Настройки сохранены','CONFIG_SAVE_FAIL':'Ошибка сохранения настроек','RELOAD_PAGE':'Обновить страницу','REFRESH':'Поменять картинку','RECAPTCHA_TEXT':'Подтвердите, что вы не робот'})</script>
<link rel="shortcut icon" href="/favicon.ico?1622699726" type="image/x-icon" />
<link rel="apple-touch-icon" sizes="180x180" href="/include/apple-touch-icon.png" />
<meta property="og:title" content="Ошибка: 404 - Страница не найдена - igc-aircon" />
<meta property="og:type" content="website" />
<meta property="og:image" content="https://igc-aircon.com/logo.png" />
<link rel="image_src" href="https://igc-aircon.com/logo.png"  />
<meta property="og:url" content="https://igc-aircon.com/bitrix/js/ui/polyfill/closest/js/closest.js" />
<meta property="og:description" content="Профессиональное проектирование и монтаж вентиляции и систем кондиционирования." />



<script  src="/bitrix/cache/js/s2/centino-heat_s2/template_cc63310dd3ca17f6545c30c54bc75763/template_cc63310dd3ca17f6545c30c54bc75763_v1.js?1455209144612384"></script>
<script  src="/bitrix/cache/js/s2/centino-heat_s2/page_7d89cddd9ab4bcc0c39dcaaab3050b71/page_7d89cddd9ab4bcc0c39dcaaab3050b71_v1.js?14552091444961"></script>
<script>var _ba = _ba || []; _ba.push(["aid", "fd7b418b540d7f59be498f35089424ba"]); _ba.push(["host", "igc-aircon.com"]); (function() {var ba = document.createElement("script"); ba.type = "text/javascript"; ba.async = true;ba.src = (document.location.protocol == "https:" ? "https://" : "http://") + "bitrix.info/ba.js";var s = document.getElementsByTagName("script")[0];s.parentNode.insertBefore(ba, s);})();</script>


				        	</head>

	<body class=" long_menu header_nopacity header_colored_main_menu hide_menu_page header_fill_ side_left all_title_2  mheader-v1 footer-vcustom fill_bg_ header-vcustom  title-v1 with_cabinet with_phones">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T9WMF4Z"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
		<div id="panel"></div>

		
				<script>
		var arBasketItems = {};
		var arHeatOptions = ({
			'SITE_DIR' : '/',
			'SITE_ID' : 's2',
			'SITE_TEMPLATE_PATH' : '/local/templates/centino-heat_s2',
			'SITE_ADDRESS' : "'igc-aircon.com\n,www.igc-aircon.com,igc-aircon.com'",
			'THEME' : ({
				'THEME_SWITCHER' : 'N',
				'BASE_COLOR' : 'CUSTOM',
				'BASE_COLOR_CUSTOM' : '35d3b7',
				'LOGO_IMAGE' : '/upload/VHeat/21b/21b0469be10ce5c153e5e4622d335a78.png',
				'LOGO_IMAGE_LIGHT' : '',
				'TOP_MENU' : '',
				'TOP_MENU_FIXED' : 'Y',
				'COLORED_LOGO' : 'N',
				'SIDE_MENU' : 'LEFT',
				'SCROLLTOTOP_TYPE' : 'NONE',
				'SCROLLTOTOP_POSITION' : 'PADDING',
				'CAPTCHA_FORM_TYPE' : 'Y',
				'PHONE_MASK' : '+7 (999) 999-99-99',
				'VALIDATE_PHONE_MASK' : '^[+][0-9] [(][0-9]{3}[)] [0-9]{3}[-][0-9]{2}[-][0-9]{2}$',
				'DATE_MASK' : 'dd.mm.yyyy',
				'DATE_PLACEHOLDER' : 'дд.мм.гггг',
				'VALIDATE_DATE_MASK' : '^[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{4}$',
				'DATETIME_MASK' : 'dd.mm.yyyy h:s',
				'DATETIME_PLACEHOLDER' : 'дд.мм.гггг чч:мм',
				'VALIDATE_DATETIME_MASK' : '^[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{4} [0-9]{1,2}\:[0-9]{1,2}$',
				'VALIDATE_FILE_EXT' : 'png|jpg|jpeg|gif|doc|docx|xls|xlsx|txt|pdf|odt|rtf',
				'SOCIAL_VK' : '',
				'SOCIAL_FACEBOOK' : '',
				'SOCIAL_TWITTER' : '',
				'SOCIAL_YOUTUBE' : '',
				'SOCIAL_ODNOKLASSNIKI' : '',
				'SOCIAL_GOOGLEPLUS' : '',
				'BANNER_WIDTH' : '',
				'TEASERS_INDEX' : 'Y',
				'CATALOG_INDEX' : 'Y',
				'YOUTUBE_INDEX' : 'Y',
				'PORTFOLIO_INDEX' : 'Y',
				'INSTAGRAMM_INDEX' : 'Y',
				'BIGBANNER_ANIMATIONTYPE' : 'SLIDE_HORIZONTAL',
				'BIGBANNER_SLIDESSHOWSPEED' : '5000',
				'BIGBANNER_ANIMATIONSPEED' : '600',
				'PARTNERSBANNER_SLIDESSHOWSPEED' : '5000',
				'PARTNERSBANNER_ANIMATIONSPEED' : '600',
				'ORDER_VIEW' : 'Y',
				'ORDER_BASKET_VIEW' : 'FLY',
				'URL_BASKET_SECTION' : '/cart/',
				'URL_ORDER_SECTION' : '/cart/order/',
				'PAGE_WIDTH' : '2',
				'PAGE_CONTACTS' : '2',
				'CATALOG_BLOCK_TYPE' : '',
				'HEADER_TYPE' : 'custom',
				'HEADER_TOP_LINE' : '',
				'HEADER_FIXED' : 'custom',
				'BREADCRUMP_FIXED' : 'Y',
				'HEADER_MOBILE' : '1',
				'HEADER_MOBILE_MENU' : '1',
				'HEADER_MOBILE_MENU_SHOW_TYPE' : '',
				'TYPE_SEARCH' : 'fixed',
				'PAGE_TITLE' : '1',
				'INDEX_TYPE' : 'index1',
				'FOOTER_TYPE' : 'custom',
				'REGIONALITY_SEARCH_ROW' : '',
				'FOOTER_TYPE' : 'custom',
				'PRINT_BUTTON' : 'N',
				'SHOW_SMARTFILTER' : 'Y',
				'LICENCE_CHECKED' : 'Y',
				'FILTER_VIEW' : 'VERTICAL',
				'YA_GOLAS' : 'Y',
				'YA_COUNTER_ID' : '65658076',
				'USE_FORMS_GOALS' : 'SINGLE',
				'USE_SALE_GOALS' : 'Y',
				'USE_DEBUG_GOALS' : 'Y',
				'IS_BASKET_PAGE' : '',
				'IS_ORDER_PAGE' : '',
				'INSTAGRAMM_TEMPLATE' : 'instagramm_1',
			}),
			"PRESETS": [{'ID':'968','TITLE':'��� 1','DESCRIPTION':'','IMG':'/bitrix/images/centino.heat/themes/preset_1.png','OPTIONS':{'THEME_SWITCHER':'Y','BASE_COLOR':'10','BASE_COLOR_CUSTOM':'0088cc','SHOW_BG_BLOCK':'N','COLORED_LOGO':'N','PAGE_WIDTH':'3','FONT_STYLE':'10','H1_STYLE':'2','TYPE_SEARCH':'fixed','PAGE_TITLE':'1','HOVER_TYPE_IMG':'shine','SHOW_LICENCE':'Y','MAX_DEPTH_MENU':'3','HIDE_SITE_NAME_TITLE':'Y','SHOW_CALLBACK':'Y','PRINT_BUTTON':'N','USE_GOOGLE_RECAPTCHA':'N','GOOGLE_RECAPTCHA_SHOW_LOGO':'Y','HIDDEN_CAPTCHA':'Y','INSTAGRAMM_WIDE_BLOCK':'N','BIGBANNER_HIDEONNARROW':'N','INDEX_TYPE':{'VALUE':'index1','SUB_PARAMS':{'BIG_BANNER_INDEX':{'VALUE':'Y','TEMPLATE':'big-banner_6'},'SLIDER_INDEX':{'VALUE':'Y','TEMPLATE':'slider_2'},'FLOAT_BANNERS_INDEX':{'VALUE':'N','TEMPLATE':'front-services_2'},'INFOBLOCK_INDEX':'Y','CATALOG_INDEX':{'VALUE':'N','TEMPLATE':'slider_with_tabs'},'CATALOG_SECTIONS_INDEX':{'VALUE':'Y','TEMPLATE':'front_1'},'PORTFOLIO_INDEX':{'VALUE':'N','TEMPLATE':'front-projects_7'},'NEWS_INDEX':{'VALUE':'N','TEMPLATE':'front-news_1'},'REVIEWS_INDEX':{'VALUE':'N','TEMPLATE':'review2'},'COMPANY_INDEX':{'VALUE':'Y','TEMPLATE':'1'},'TEASERS_INDEX':{'VALUE':'Y','TEMPLATE':'front_tizers_2'},'PARTNERS_INDEX':'Y','BLOG_INDEX':{'VALUE':'N','TEMPLATE':'front-blog_4'},'INSTAGRAMM_INDEX':{'VALUE':'Y','TEMPLATE':'instagramm_1'},'YOUTUBE_INDEX':'N','MAP_INDEX':'N'},'ORDER':'BIG_BANNER_INDEX,TEASERS_INDEX,SLIDER_INDEX,CATALOG_SECTIONS_INDEX,PARTNERS_INDEX,INFOBLOCK_INDEX,FLOAT_BANNERS_INDEX,CATALOG_INDEX,PORTFOLIO_INDEX,NEWS_INDEX,REVIEWS_INDEX,COMPANY_INDEX,BLOG_INDEX,INSTAGRAMM_INDEX,YOUTUBE_INDEX,MAP_INDEX'},'FRONT_PAGE_BRANDS':'brands_slider','FRONT_PAGE_SECTIONS':'front_sections_only','TOP_MENU_FIXED':'Y','HEADER_TYPE':'3','USE_REGIONALITY':'N','FILTER_VIEW':'COMPACT','SEARCH_VIEW_TYPE':'with_filter','USE_FAST_VIEW_PAGE_DETAIL':'fast_view_1','SHOW_TOTAL_SUMM':'Y','CHANGE_TITLE_ITEM':'N','VIEW_TYPE_HIGHLOAD_PROP':'N','SHOW_HEADER_GOODS':'Y','SEARCH_HIDE_NOT_AVAILABLE':'N','LEFT_BLOCK_CATALOG_ICONS':'N','SHOW_CATALOG_SECTIONS_ICONS':'Y','LEFT_BLOCK_CATALOG_DETAIL':'Y','CATALOG_COMPARE':'Y','CATALOG_PAGE_DETAIL':'element_1','SHOW_BREADCRUMBS_CATALOG_SUBSECTIONS':'Y','SHOW_BREADCRUMBS_CATALOG_CHAIN':'H1','TYPE_SKU':'TYPE_1','DETAIL_PICTURE_MODE':'POPUP','MENU_POSITION':'LINE','MENU_TYPE_VIEW':'HOVER','VIEWED_TYPE':'LOCAL','VIEWED_TEMPLATE':'HORIZONTAL','USE_WORD_EXPRESSION':'Y','ORDER_BASKET_VIEW':'HEADER','ORDER_BASKET_COLOR':'DARK','SHOW_BASKET_ONADDTOCART':'Y','SHOW_BASKET_PRINT':'Y','SHOW_BASKET_ON_PAGES':'N','USE_PRODUCT_QUANTITY_LIST':'Y','USE_PRODUCT_QUANTITY_DETAIL':'Y','ONE_CLICK_BUY_CAPTCHA':'N','SHOW_ONECLICKBUY_ON_BASKET_PAGE':'Y','ONECLICKBUY_SHOW_DELIVERY_NOTE':'N','PAGE_CONTACTS':'1','CONTACTS_USE_FEEDBACK':'Y','CONTACTS_USE_MAP':'Y','BLOG_PAGE':'list_elements_1','PROJECTS_PAGE':'list_elements_2','NEWS_PAGE':'list_elements_2','STAFF_PAGE':'list_elements_1','PARTNERS_PAGE':'list_elements_3','PARTNERS_PAGE_DETAIL':'element_3','VACANCY_PAGE':'list_elements_1','LICENSES_PAGE':'list_elements_1','FOOTER_TYPE':'10','ADV_TOP_HEADER':'N','ADV_TOP_UNDERHEADER':'N','ADV_SIDE':'Y','ADV_CONTENT_TOP':'N','ADV_CONTENT_BOTTOM':'N','ADV_FOOTER':'N','HEADER_MOBILE_FIXED':'Y','HEADER_MOBILE':'1','HEADER_MOBILE_MENU':'1','HEADER_MOBILE_MENU_OPEN':'1','PERSONAL_ONEFIO':'Y','LOGIN_EQUAL_EMAIL':'N','YA_GOALS':'N','YANDEX_ECOMERCE':'N','GOOGLE_ECOMERCE':'N','CALLBACK_BUTTON':'Y','RIGHT_FORM_BLOCK':'N','HEADER_ADV_SERVICES':'Y','HEADER_ICONS_SERVICES':'Y','HEADER_ADV_CATALOG':'Y','HEADER_ICONS_CATALOG':'N','ORDER_VIEW':'N','SHOW_SMARTFILTER':'N','SHOW_LEFT_BLOCK':'Y','SECTIONS_TYPE_VIEW_CATALOG':'sections_1','SECTION_TYPE_VIEW_CATALOG':'section_3','ELEMENTS_TABLE_TYPE_VIEW':'catalog_table','SECTIONS_TYPE_VIEW':'sections_1','SECTION_TYPE_VIEW':'section_2','ELEMENTS_PAGE':'list_elements_1','ELEMENT_PAGE_DETAIL':'element_1','ELEMENTS_PROJECT_PAGE':'list_elements_2','SHOW_PROJECTS_MAP':'Y','CABINET':'Y','SIDE_MENU':'LEFT','VIEW_TYPE_LEFT_BLOCK':'normal','COUNT_ITEMS_IN_LINE_MENU':'3','YA_GOLAS':'N','BREADCRUMP_FIXED':'Y','SHOW_PROJECTS_MAP_SECTIONS':'Y','SHOW_PROJECTS_MAP_DETAIL':'Y'}},{'ID':'221','TITLE':'��� 2','DESCRIPTION':'','IMG':'/bitrix/images/centino.heat/themes/preset_2.png','OPTIONS':{'THEME_SWITCHER':'Y','BASE_COLOR':'20','BASE_COLOR_CUSTOM':'216ef0','SHOW_BG_BLOCK':'N','COLORED_LOGO':'Y','PAGE_WIDTH':'3','FONT_STYLE':'10','MENU_COLOR':'LIGHT','LEFT_BLOCK':'2','SIDE_MENU':'LEFT','H1_STYLE':'2','TYPE_SEARCH':'fixed','PAGE_TITLE':'1','HOVER_TYPE_IMG':'shine','SHOW_LICENCE':'Y','MAX_DEPTH_MENU':'4','HIDE_SITE_NAME_TITLE':'Y','SHOW_CALLBACK':'Y','PRINT_BUTTON':'N','USE_GOOGLE_RECAPTCHA':'N','GOOGLE_RECAPTCHA_SHOW_LOGO':'Y','HIDDEN_CAPTCHA':'Y','INSTAGRAMM_WIDE_BLOCK':'N','BIGBANNER_HIDEONNARROW':'N','INDEX_TYPE':{'VALUE':'index1','SUB_PARAMS':{'BIG_BANNER_INDEX':{'VALUE':'Y','TEMPLATE':'big-banner_2'},'SLIDER_INDEX':{'VALUE':'Y','TEMPLATE':'slider_1'},'FLOAT_BANNERS_INDEX':{'VALUE':'Y','TEMPLATE':'front-services_2'},'INFOBLOCK_INDEX':'Y','CATALOG_INDEX':{'VALUE':'Y','TEMPLATE':'slider_with_tabs'},'CATALOG_SECTIONS_INDEX':{'VALUE':'N','TEMPLATE':'front_1'},'PORTFOLIO_INDEX':{'VALUE':'N','TEMPLATE':'front-projects_7'},'NEWS_INDEX':{'VALUE':'N','TEMPLATE':'front-news_1'},'REVIEWS_INDEX':{'VALUE':'Y','TEMPLATE':'review1'},'COMPANY_INDEX':{'VALUE':'Y','TEMPLATE':'1'},'TEASERS_INDEX':{'VALUE':'Y','TEMPLATE':'front_tizers_3'},'PARTNERS_INDEX':'N','BLOG_INDEX':{'VALUE':'Y','TEMPLATE':'front-blog_4'},'INSTAGRAMM_INDEX':{'VALUE':'N','TEMPLATE':'instagramm_1'},'YOUTUBE_INDEX':'N','MAP_INDEX':'N'},'ORDER':'BIG_BANNER_INDEX,SLIDER_INDEX,FLOAT_BANNERS_INDEX,INFOBLOCK_INDEX,CATALOG_SECTIONS_INDEX,CATALOG_INDEX,PORTFOLIO_INDEX,NEWS_INDEX,REVIEWS_INDEX,COMPANY_INDEX,TEASERS_INDEX,PARTNERS_INDEX,BLOG_INDEX,INSTAGRAMM_INDEX,YOUTUBE_INDEX,MAP_INDEX'},'FRONT_PAGE_BRANDS':'brands_slider','FRONT_PAGE_SECTIONS':'front_sections_with_childs','TOP_MENU_FIXED':'Y','HEADER_TYPE':'3','USE_REGIONALITY':'N','FILTER_VIEW':'VERTICAL','SEARCH_VIEW_TYPE':'with_filter','USE_FAST_VIEW_PAGE_DETAIL':'fast_view_1','SHOW_TOTAL_SUMM':'Y','CHANGE_TITLE_ITEM':'N','VIEW_TYPE_HIGHLOAD_PROP':'N','SHOW_HEADER_GOODS':'Y','SEARCH_HIDE_NOT_AVAILABLE':'N','LEFT_BLOCK_CATALOG_ICONS':'N','SHOW_CATALOG_SECTIONS_ICONS':'Y','LEFT_BLOCK_CATALOG_DETAIL':'Y','CATALOG_COMPARE':'Y','CATALOG_PAGE_DETAIL':'element_1','SHOW_BREADCRUMBS_CATALOG_SUBSECTIONS':'Y','SHOW_BREADCRUMBS_CATALOG_CHAIN':'H1','TYPE_SKU':'TYPE_1','DETAIL_PICTURE_MODE':'POPUP','MENU_POSITION':'LINE','MENU_TYPE_VIEW':'HOVER','VIEWED_TYPE':'LOCAL','VIEWED_TEMPLATE':'HORIZONTAL','USE_WORD_EXPRESSION':'Y','ORDER_BASKET_VIEW':'HEADER','ORDER_BASKET_COLOR':'DARK','SHOW_BASKET_ONADDTOCART':'Y','SHOW_BASKET_PRINT':'Y','SHOW_BASKET_ON_PAGES':'N','USE_PRODUCT_QUANTITY_LIST':'Y','USE_PRODUCT_QUANTITY_DETAIL':'Y','ONE_CLICK_BUY_CAPTCHA':'N','SHOW_ONECLICKBUY_ON_BASKET_PAGE':'Y','ONECLICKBUY_SHOW_DELIVERY_NOTE':'N','PAGE_CONTACTS':'1','CONTACTS_USE_FEEDBACK':'Y','CONTACTS_USE_MAP':'Y','BLOG_PAGE':'list_elements_1','PROJECTS_PAGE':'list_elements_2','NEWS_PAGE':'list_elements_2','STAFF_PAGE':'list_elements_1','PARTNERS_PAGE':'list_elements_3','PARTNERS_PAGE_DETAIL':'element_3','VACANCY_PAGE':'list_elements_1','LICENSES_PAGE':'list_elements_1','FOOTER_TYPE':'8','ADV_TOP_HEADER':'N','ADV_TOP_UNDERHEADER':'N','ADV_SIDE':'Y','ADV_CONTENT_TOP':'N','ADV_CONTENT_BOTTOM':'N','ADV_FOOTER':'N','HEADER_MOBILE_FIXED':'Y','HEADER_MOBILE':'1','HEADER_MOBILE_MENU':'1','HEADER_MOBILE_MENU_OPEN':'1','PERSONAL_ONEFIO':'Y','LOGIN_EQUAL_EMAIL':'N','YA_GOALS':'N','YANDEX_ECOMERCE':'N','GOOGLE_ECOMERCE':'N','CALLBACK_BUTTON':'Y','RIGHT_FORM_BLOCK':'N','HEADER_ADV_SERVICES':'Y','HEADER_ICONS_SERVICES':'Y','HEADER_ADV_CATALOG':'Y','HEADER_ICONS_CATALOG':'N','ORDER_VIEW':'N','SHOW_SMARTFILTER':'Y','SHOW_LEFT_BLOCK':'Y','SECTIONS_TYPE_VIEW_CATALOG':'sections_1','SECTION_TYPE_VIEW_CATALOG':'section_3','ELEMENTS_TABLE_TYPE_VIEW':'catalog_table','SECTIONS_TYPE_VIEW':'sections_1','SECTION_TYPE_VIEW':'section_2','ELEMENTS_PAGE':'list_elements_1','ELEMENT_PAGE_DETAIL':'element_1','ELEMENTS_PROJECT_PAGE':'list_elements_2','SHOW_PROJECTS_MAP':'Y','CABINET':'Y','VIEW_TYPE_LEFT_BLOCK':'normal','COUNT_ITEMS_IN_LINE_MENU':'3','YA_GOLAS':'N','BREADCRUMP_FIXED':'Y','SHOW_PROJECTS_MAP_SECTIONS':'Y','SHOW_PROJECTS_MAP_DETAIL':'Y'}},{'ID':'215','TITLE':'��� 3','DESCRIPTION':'','IMG':'/bitrix/images/centino.heat/themes/preset_3.png','OPTIONS':{'THEME_SWITCHER':'Y','BASE_COLOR':'13','BASE_COLOR_CUSTOM':'0fa8ae','SHOW_BG_BLOCK':'N','COLORED_LOGO':'Y','PAGE_WIDTH':'3','FONT_STYLE':'10','MENU_COLOR':'LIGHT','LEFT_BLOCK':'3','SIDE_MENU':'LEFT','H1_STYLE':'2','TYPE_SEARCH':'fixed','PAGE_TITLE':'1','HOVER_TYPE_IMG':'shine','SHOW_LICENCE':'Y','MAX_DEPTH_MENU':'4','HIDE_SITE_NAME_TITLE':'Y','SHOW_CALLBACK':'Y','PRINT_BUTTON':'Y','USE_GOOGLE_RECAPTCHA':'N','GOOGLE_RECAPTCHA_SHOW_LOGO':'Y','HIDDEN_CAPTCHA':'Y','INSTAGRAMM_WIDE_BLOCK':'N','BIGBANNER_HIDEONNARROW':'N','INDEX_TYPE':{'VALUE':'index1','SUB_PARAMS':{'BIG_BANNER_INDEX':{'VALUE':'Y','TEMPLATE':'big-banner_1'},'SLIDER_INDEX':{'VALUE':'N','TEMPLATE':'slider_1'},'FLOAT_BANNERS_INDEX':{'VALUE':'Y','TEMPLATE':'front-services_new'},'INFOBLOCK_INDEX':'N','CATALOG_INDEX':{'VALUE':'N','TEMPLATE':'slider_with_tabs'},'CATALOG_SECTIONS_INDEX':{'VALUE':'Y','TEMPLATE':'front_1'},'PORTFOLIO_INDEX':{'VALUE':'Y','TEMPLATE':'front-projects_1'},'NEWS_INDEX':{'VALUE':'N','TEMPLATE':'front-news_1'},'REVIEWS_INDEX':{'VALUE':'N','TEMPLATE':'review2'},'COMPANY_INDEX':{'VALUE':'N','TEMPLATE':'1'},'TEASERS_INDEX':{'VALUE':'Y','TEMPLATE':'front_tizers_3'},'PARTNERS_INDEX':'N','BLOG_INDEX':{'VALUE':'Y','TEMPLATE':'front-blog_4'},'INSTAGRAMM_INDEX':{'VALUE':'Y','TEMPLATE':'instagramm_1'},'YOUTUBE_INDEX':'N','MAP_INDEX':'N'},'ORDER':'BIG_BANNER_INDEX,SLIDER_INDEX,FLOAT_BANNERS_INDEX,INFOBLOCK_INDEX,TEASERS_INDEX,PORTFOLIO_INDEX,CATALOG_INDEX,CATALOG_SECTIONS_INDEX,COMPANY_INDEX,PARTNERS_INDEX,NEWS_INDEX,REVIEWS_INDEX,BLOG_INDEX,INSTAGRAMM_INDEX,MAP_INDEX'},'FRONT_PAGE_BRANDS':'brands_list','FRONT_PAGE_SECTIONS':'front_sections_with_childs','TOP_MENU_FIXED':'Y','HEADER_TYPE':'2','USE_REGIONALITY':'N','FILTER_VIEW':'VERTICAL','SEARCH_VIEW_TYPE':'with_filter','USE_FAST_VIEW_PAGE_DETAIL':'fast_view_1','SHOW_TOTAL_SUMM':'Y','CHANGE_TITLE_ITEM':'N','VIEW_TYPE_HIGHLOAD_PROP':'N','SHOW_HEADER_GOODS':'Y','SEARCH_HIDE_NOT_AVAILABLE':'N','LEFT_BLOCK_CATALOG_ICONS':'N','SHOW_CATALOG_SECTIONS_ICONS':'Y','LEFT_BLOCK_CATALOG_DETAIL':'Y','CATALOG_COMPARE':'Y','CATALOG_PAGE_DETAIL':'element_1','SHOW_BREADCRUMBS_CATALOG_SUBSECTIONS':'Y','SHOW_BREADCRUMBS_CATALOG_CHAIN':'H1','TYPE_SKU':'TYPE_1','DETAIL_PICTURE_MODE':'POPUP','MENU_POSITION':'LINE','MENU_TYPE_VIEW':'HOVER','VIEWED_TYPE':'LOCAL','VIEWED_TEMPLATE':'HORIZONTAL','USE_WORD_EXPRESSION':'Y','ORDER_BASKET_VIEW':'HEADER','ORDER_BASKET_COLOR':'DARK','SHOW_BASKET_ONADDTOCART':'Y','SHOW_BASKET_PRINT':'Y','SHOW_BASKET_ON_PAGES':'N','USE_PRODUCT_QUANTITY_LIST':'Y','USE_PRODUCT_QUANTITY_DETAIL':'Y','ONE_CLICK_BUY_CAPTCHA':'N','SHOW_ONECLICKBUY_ON_BASKET_PAGE':'Y','ONECLICKBUY_SHOW_DELIVERY_NOTE':'N','PAGE_CONTACTS':'2','CONTACTS_USE_FEEDBACK':'Y','CONTACTS_USE_MAP':'Y','BLOG_PAGE':'list_elements_2','PROJECTS_PAGE':'list_elements_2','NEWS_PAGE':'list_elements_3','STAFF_PAGE':'list_elements_1','PARTNERS_PAGE':'list_elements_3','PARTNERS_PAGE_DETAIL':'element_1','VACANCY_PAGE':'list_elements_1','LICENSES_PAGE':'list_elements_2','FOOTER_TYPE':'9','ADV_TOP_HEADER':'N','ADV_TOP_UNDERHEADER':'N','ADV_SIDE':'Y','ADV_CONTENT_TOP':'N','ADV_CONTENT_BOTTOM':'N','ADV_FOOTER':'N','HEADER_MOBILE_FIXED':'Y','HEADER_MOBILE':'1','HEADER_MOBILE_MENU':'1','HEADER_MOBILE_MENU_OPEN':'1','PERSONAL_ONEFIO':'Y','LOGIN_EQUAL_EMAIL':'Y','YA_GOALS':'N','YANDEX_ECOMERCE':'N','GOOGLE_ECOMERCE':'N','CALLBACK_BUTTON':'Y','RIGHT_FORM_BLOCK':'Y','HEADER_ADV_SERVICES':'Y','HEADER_ICONS_SERVICES':'Y','HEADER_ADV_CATALOG':'Y','HEADER_ICONS_CATALOG':'N','ORDER_VIEW':'Y','SHOW_SMARTFILTER':'Y','SHOW_LEFT_BLOCK':'Y','SECTIONS_TYPE_VIEW_CATALOG':'sections_1','SECTION_TYPE_VIEW_CATALOG':'section_2','ELEMENTS_TABLE_TYPE_VIEW':'catalog_table','SECTIONS_TYPE_VIEW':'sections_3','SECTION_TYPE_VIEW':'section_2','ELEMENTS_PAGE':'list_elements_1','ELEMENT_PAGE_DETAIL':'element_2','ELEMENTS_PROJECT_PAGE':'list_elements_2','SHOW_PROJECTS_MAP':'Y','CABINET':'N','VIEW_TYPE_LEFT_BLOCK':'normal','COUNT_ITEMS_IN_LINE_MENU':'3','YA_GOLAS':'N','BREADCRUMP_FIXED':'Y','SHOW_PROJECTS_MAP_SECTIONS':'Y','SHOW_PROJECTS_MAP_DETAIL':'Y'}},{'ID':'881','TITLE':'��� 4','DESCRIPTION':'','IMG':'/bitrix/images/centino.heat/themes/preset_4.png','OPTIONS':{'THEME_SWITCHER':'Y','BASE_COLOR':'5','BASE_COLOR_CUSTOM':'b41818','SHOW_BG_BLOCK':'N','COLORED_LOGO':'Y','PAGE_WIDTH':'3','FONT_STYLE':'10','MENU_COLOR':'COLORED','LEFT_BLOCK':'2','SIDE_MENU':'LEFT','H1_STYLE':'2','TYPE_SEARCH':'fixed','PAGE_TITLE':'1','HOVER_TYPE_IMG':'blink','SHOW_LICENCE':'Y','MAX_DEPTH_MENU':'4','HIDE_SITE_NAME_TITLE':'Y','SHOW_CALLBACK':'Y','PRINT_BUTTON':'N','USE_GOOGLE_RECAPTCHA':'N','GOOGLE_RECAPTCHA_SHOW_LOGO':'Y','HIDDEN_CAPTCHA':'Y','INSTAGRAMM_WIDE_BLOCK':'N','BIGBANNER_HIDEONNARROW':'N','INDEX_TYPE':{'VALUE':'index1','SUB_PARAMS':{'BIG_BANNER_INDEX':{'VALUE':'Y','TEMPLATE':'big-banner_4'},'SLIDER_INDEX':{'VALUE':'N','TEMPLATE':'slider_1'},'FLOAT_BANNERS_INDEX':{'VALUE':'Y','TEMPLATE':'front-services_2'},'INFOBLOCK_INDEX':'Y','CATALOG_INDEX':{'VALUE':'Y','TEMPLATE':'slider_with_tabs'},'CATALOG_SECTIONS_INDEX':{'VALUE':'N','TEMPLATE':'front_1'},'PORTFOLIO_INDEX':{'VALUE':'Y','TEMPLATE':'front-projects_2'},'NEWS_INDEX':{'VALUE':'N','TEMPLATE':'front-news_1'},'REVIEWS_INDEX':{'VALUE':'Y','TEMPLATE':'review1'},'COMPANY_INDEX':{'VALUE':'Y','TEMPLATE':'1'},'TEASERS_INDEX':{'VALUE':'N','TEMPLATE':'front_tizers_1'},'PARTNERS_INDEX':'Y','BLOG_INDEX':{'VALUE':'Y','TEMPLATE':'front-blog_1'},'INSTAGRAMM_INDEX':{'VALUE':'Y','TEMPLATE':'instagramm_1'},'YOUTUBE_INDEX':'N','MAP_INDEX':'Y'},'ORDER':'BIG_BANNER_INDEX,SLIDER_INDEX,FLOAT_BANNERS_INDEX,INFOBLOCK_INDEX,PORTFOLIO_INDEX,CATALOG_INDEX,CATALOG_SECTIONS_INDEX,COMPANY_INDEX,PARTNERS_INDEX,NEWS_INDEX,TEASERS_INDEX,REVIEWS_INDEX,BLOG_INDEX,INSTAGRAMM_INDEX,MAP_INDEX'},'FRONT_PAGE_BRANDS':'brands_slider','FRONT_PAGE_SECTIONS':'front_sections_with_childs','TOP_MENU_FIXED':'Y','HEADER_TYPE':'1','USE_REGIONALITY':'N','FILTER_VIEW':'COMPACT','SEARCH_VIEW_TYPE':'with_filter','USE_FAST_VIEW_PAGE_DETAIL':'fast_view_1','SHOW_TOTAL_SUMM':'Y','CHANGE_TITLE_ITEM':'N','VIEW_TYPE_HIGHLOAD_PROP':'N','SHOW_HEADER_GOODS':'Y','SEARCH_HIDE_NOT_AVAILABLE':'N','LEFT_BLOCK_CATALOG_ICONS':'N','SHOW_CATALOG_SECTIONS_ICONS':'Y','LEFT_BLOCK_CATALOG_DETAIL':'Y','CATALOG_COMPARE':'Y','CATALOG_PAGE_DETAIL':'element_1','SHOW_BREADCRUMBS_CATALOG_SUBSECTIONS':'Y','SHOW_BREADCRUMBS_CATALOG_CHAIN':'H1','TYPE_SKU':'TYPE_1','DETAIL_PICTURE_MODE':'POPUP','MENU_POSITION':'LINE','MENU_TYPE_VIEW':'HOVER','VIEWED_TYPE':'LOCAL','VIEWED_TEMPLATE':'HORIZONTAL','USE_WORD_EXPRESSION':'Y','ORDER_BASKET_VIEW':'HEADER','ORDER_BASKET_COLOR':'DARK','SHOW_BASKET_ONADDTOCART':'Y','SHOW_BASKET_PRINT':'Y','SHOW_BASKET_ON_PAGES':'N','USE_PRODUCT_QUANTITY_LIST':'Y','USE_PRODUCT_QUANTITY_DETAIL':'Y','ONE_CLICK_BUY_CAPTCHA':'N','SHOW_ONECLICKBUY_ON_BASKET_PAGE':'Y','ONECLICKBUY_SHOW_DELIVERY_NOTE':'N','PAGE_CONTACTS':'2','CONTACTS_USE_FEEDBACK':'Y','CONTACTS_USE_MAP':'Y','BLOG_PAGE':'list_elements_2','PROJECTS_PAGE':'list_elements_2','NEWS_PAGE':'list_elements_3','STAFF_PAGE':'list_elements_1','PARTNERS_PAGE':'list_elements_3','PARTNERS_PAGE_DETAIL':'element_1','VACANCY_PAGE':'list_elements_1','LICENSES_PAGE':'list_elements_2','FOOTER_TYPE':'11','ADV_TOP_HEADER':'N','ADV_TOP_UNDERHEADER':'N','ADV_SIDE':'Y','ADV_CONTENT_TOP':'N','ADV_CONTENT_BOTTOM':'N','ADV_FOOTER':'N','HEADER_MOBILE_FIXED':'Y','HEADER_MOBILE':'1','HEADER_MOBILE_MENU':'1','HEADER_MOBILE_MENU_OPEN':'1','PERSONAL_ONEFIO':'Y','LOGIN_EQUAL_EMAIL':'Y','YA_GOALS':'N','YANDEX_ECOMERCE':'N','GOOGLE_ECOMERCE':'N','CALLBACK_BUTTON':'Y','RIGHT_FORM_BLOCK':'Y','HEADER_ADV_SERVICES':'Y','HEADER_ICONS_SERVICES':'Y','HEADER_ADV_CATALOG':'Y','HEADER_ICONS_CATALOG':'N','ORDER_VIEW':'Y','SHOW_SMARTFILTER':'Y','SHOW_LEFT_BLOCK':'Y','SECTIONS_TYPE_VIEW_CATALOG':'sections_2','SECTION_TYPE_VIEW_CATALOG':'section_2','ELEMENTS_TABLE_TYPE_VIEW':'catalog_table','SECTIONS_TYPE_VIEW':'sections_1','SECTION_TYPE_VIEW':'section_2','ELEMENTS_PAGE':'list_elements_1','ELEMENT_PAGE_DETAIL':'element_1','ELEMENTS_PROJECT_PAGE':'list_elements_2','SHOW_PROJECTS_MAP':'Y','CABINET':'Y','VIEW_TYPE_LEFT_BLOCK':'normal','COUNT_ITEMS_IN_LINE_MENU':'3','YA_GOLAS':'N','BREADCRUMP_FIXED':'Y'}}]		});
		if(arHeatOptions.SITE_ADDRESS)
			arHeatOptions.SITE_ADDRESS = arHeatOptions.SITE_ADDRESS.replace(/'/g, "");
		</script>
		<!--'start_frame_cache_options-block'-->			<script>
				var arBasketItems = [];
			</script>
		<!--'end_frame_cache_options-block'-->				



		



				<div class="visible-lg visible-md title-v1">
			<header class="header_custom long ">
	<div class="top-block without_menu">
		<div class="maxwidth-theme hght-100">
			<div class="top_menu_wrapper hght-100 col-md-12">
								<div class="logo-block col-md-4 flex-row-vc hght-100 p-l-0">
					<div class="logo" style="padding-right:10px;">
						<a href="/"><img src="/upload/VHeat/21b/21b0469be10ce5c153e5e4622d335a78.png" alt="igc-aircon" title="igc-aircon" /></a>					</div>
									<div class="slogan flex-row-vc hght-100">
						<div class="top-description fs-19 color-555 lh-150">
							<div>
								Бытовые и промышленные<br>
климатические системы							</div>
						</div>
					</div>
								</div>
												<div class="top-block-item address col-md-2 flex-row-vc hght-100 lh-12 fill-theme">
					<i class="svg inline  svg-inline-" aria-hidden="true" ><svg width="12" height="15" viewBox="0 0 12 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M6 0C7.5913 0 9.1174 0.632144 10.2426 1.75736C11.3678 2.88258 12 4.4087 12 6C12 9.314 6 15 6 15C6 15 0 9.314 0 6C0 4.4087 0.632167 2.88258 1.75739 1.75736C2.8826 0.632144 4.4087 0 6 0ZM6 2C7.06087 2 8.07828 2.42142 8.82843 3.17157C9.57858 3.92172 10 4.93913 10 6C10 8.209 6 12.568 6 12.568C6 12.568 2 8.209 2 6C2 4.93913 2.42142 3.92172 3.17157 3.17157C3.92172 2.42142 4.93913 2 6 2Z" fill="#216EF0"/>
</svg>
</i>					
		
												<div class="address inline-block ">
																				<span class="city">
								Москва 							</span>
																			<span class="header_address">
								<br>ш. Энтузиастов, д. 17							</span>
											</div>
							
							</div>
								<div class="top-block-item phone col-md-2 flex-row-vc hght-100 lh-125">
					<div class="phone-block flex-row flex-wrap">
													<div class="inline-block">
																		
									<table>
														<div class="icon">
							<i class="svg inline  svg-inline-phone fill-theme" aria-hidden="true" ><svg width="12" height="15" viewBox="0 0 12 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7 9H5V11H7V9Z" fill="#35ABEF"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M0 2C0 0.895447 0.895386 0 2 0H10C11.1046 0 12 0.895447 12 2V13C12 14.1046 11.1046 15 10 15H2C0.895386 15 0 14.1046 0 13V2ZM2 2H10V13H2V2Z" fill="#35ABEF"/>
</svg>
</i>	
						</div>
											<div class="wrapper">
							<div class="fs-14 color-888"></div>
															<div itemprop="telephone" class=" phone_number_click centino_header_phone fs-15 color-333 wgt-600">+7 (495) 212-07-22<br></div>
													</div>
							</table>
																</div>
																			<div class="inline-block form">
								<span class="feedback_call_click callback-block animate-load colored fs-13" data-event="jqm" data-param-id="55" data-name="callback">Заказать звонок</span>
							</div>
											</div>
				</div>
								<div class="icons-block pull-right flex-row-vc hght-100">
					<div class="col-md-12 nopadding-right nopadding-left">
						<div class="right-icons wide pull-right wdt-100">
																						<div class="pull-right">
									<div class="wrap_icon inner-table-block">
<a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://vk.com/igcaircon">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/icon-vk.svg" alt="vk">
                            </a>
                            <a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://www.youtube.com/channel/UCEU_d9DAPexWdPNLd8cSlYA">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/icon-youtube.svg" alt="youtube">
                            </a>							
                            <a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://t.me/igcaircon">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/tg.svg" alt="vk">
                            </a>
                            <a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://ok.ru/igcaircon">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ok.svg" alt="vk">
                            </a>
                            <a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://igcaircon.clients.site/">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ya-biz.svg" alt="vk">
                            </a>
                            <a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://zen.yandex.ru/id/6229b31acbc61a17d6b94825">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ya-zen.svg" alt="vk">
                            </a>
									</div>
								</div>
							<div class="pull-right">
								<div class="wrap_icon inner-table-block">

<a class="btn btn--red btn-consultation feedback_call_click callback-block animate-load" href="#" data-event="jqm" data-param-id="55" data-name="callback">Получить консультацию</a>								</div>
							</div>

							<div class="pull-right">
								<div class="wrap_icon inner-table-block">
									<button class="inline-search-show twosmallfont n-border bg-trans" title="Поиск">
										<i class="svg inline  svg-inline-search" aria-hidden="true" ><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M12.7609 14.2586C11.4245 15.2797 9.75459 15.8861 7.94299 15.8861C3.55625 15.8861 0 12.3299 0 7.94307C0 3.55622 3.55625 0 7.94299 0C12.3297 0 15.886 3.55622 15.886 7.94307C15.886 9.75463 15.2795 11.4245 14.2586 12.7608L17.6898 16.192C18.1034 16.6057 18.1034 17.2762 17.6898 17.6898C17.2761 18.1034 16.6057 18.1034 16.192 17.6898L12.7609 14.2586ZM13.7678 7.94307C13.7678 11.1601 11.16 13.768 7.94299 13.768C4.72597 13.768 2.11813 11.1601 2.11813 7.94307C2.11813 4.72609 4.72597 2.11815 7.94299 2.11815C11.16 2.11815 13.7678 4.72609 13.7678 7.94307Z" fill="#888888"/>
</svg>
</i>									</button>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="lines"></div>
	</div>
    
    <section class="ctm-main-menu">
        <section class="ctm-main-menu-inner">
            <ul class="ctm-main-menu-list">
                <li class="ctm-main-menu-list-item">
                    <a class="ctm-main-menu-list-item-link" href="#">Компания</a>
                    <ul class="ctm-main-menu-sublist">
                        <li class="ctm-main-menu-sublist-item">
                            <a class="ctm-main-menu-sublist-link" href="/company/index.php">О компании</a>
                        </li>
                        <li class="ctm-main-menu-sublist-item">
                            <a class="ctm-main-menu-sublist-link" href="/company/history/">История</a>
                        </li>
                        <li class="ctm-main-menu-sublist-item">
                            <a class="ctm-main-menu-sublist-link" href="/company/partners/">Партнёры</a>
                        </li>
                        <li class="ctm-main-menu-sublist-item">
                            <a class="ctm-main-menu-sublist-link" href="/company/reviews/">Отзывы</a>
                        </li>
                        <li class="ctm-main-menu-sublist-item">
                            <a class="ctm-main-menu-sublist-link" href="/company/vacancy/">Вакансии</a>
                        </li>
                    </ul>
                </li>
                <li class="ctm-main-menu-list-item ctm-main-menu-list-item--with-submenu">
                    <a class="ctm-main-menu-list-item-link" href="/product/">Оборудование</a>
                    <section class="ctm-main-menu-submenu">
                        <section class="ctm-main-menu-submenu-container">
                            <section class="ctm-main-menu-submenu-list-wrapper">
                                <img class="ctm-main-menu-submenu-list-cover" src="https://www.igc-aircon.com/upload/resize_cache/iblock/6a8/60_60_1/6a81fe4e54f68127afd08d7ddc886733.jpg">
                                <h2 class="ctm-main-menu-submenu-list-name">
                                    <a class="ctm-main-menu-submenu-link" href="/product/bytovye_split_sistemy/">Бытовые сплит-системы</a>
                                </h2>
                                <ul class="ctm-main-menu-submenu-list">
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/bytovye_split_sistemy/split_sistemy/">Сплит-системы</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/bytovye_split_sistemy/multisplit_sistemy/">Мультисплит-системы</a>
                                    </li>
                                </ul>
                            </section>
                            <section class="ctm-main-menu-submenu-list-wrapper">
                                <img class="ctm-main-menu-submenu-list-cover" src="https://www.igc-aircon.com/upload/resize_cache/iblock/063/60_60_1/0637b6cb969e1ee40ffd2b3b88bd4bb5.jpg">
                                <a href="/product/polupromyshlennye_konditsionery/">
                                <h2 class="ctm-main-menu-submenu-list-name">Полупромышленные кондиционеры</h2></a>
                                <ul class="ctm-main-menu-submenu-list">
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/polupromyshlennye_konditsionery/kanalnye_split_sistemy/">Канальные сплит-системы</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/polupromyshlennye_konditsionery/kassetnye_split_sistemy/">Кассетные сплит-системы</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/polupromyshlennye_konditsionery/kolonnye_split_sistemy/">Колонные сплит-системы</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/polupromyshlennye_konditsionery/napolno_potolochnye_split_sistemy/">Напольно-потолочные сплит-системы</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/polupromyshlennye_konditsionery/naruzhnye-bloki/">Наружные блоки</a>
                                    </li>
                                </ul>
                            </section>
                        </section>
                        <section class="ctm-main-menu-submenu-container">
                            <section class="ctm-main-menu-submenu-list-wrapper">
                                <img class="ctm-main-menu-submenu-list-cover" src="https://www.igc-aircon.com/upload/resize_cache/iblock/3c6/60_60_1/3c61c4ea1471984917258f6219bb8bab.jpg">
                                <a href="/product/multizonalnye_vrf_sistemy/">
                                <h2 class="ctm-main-menu-submenu-list-name">Мультизональные VRF-системы</h2></a>
                                <ul class="ctm-main-menu-submenu-list">
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/multizonalnye_vrf_sistemy/vysokonapornye_kanalnye_vnutrennie_bloki/">Высоконапорные канальные внутренние блоки</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/multizonalnye_vrf_sistemy/individualnye-vrf/">Индивидуальные VRF</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/multizonalnye_vrf_sistemy/kassetnye_vnutrennie_bloki/">Кассетные внутренние блоки</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/multizonalnye_vrf_sistemy/modulnye_naruzhnye_bloki/">Модульные наружные блоки</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/multizonalnye_vrf_sistemy/napolno_potolochnye_vnutrennie_bloki/">Напольно-потолочные внутренние блоки</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/multizonalnye_vrf_sistemy/naruzhnye_bloki_mini/">Наружные блоки Mini</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/multizonalnye_vrf_sistemy/nastennye_vnutrennie_bloki/">Настенные внутренние блоки</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/multizonalnye_vrf_sistemy/nizkonapornye_kanalnye_vnutrennie_bloki/">Низконапорные канальные внутренние блоки</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/multizonalnye_vrf_sistemy/srednenapornye_kanalnye_vnutrennie_bloki/">Средненапорные канальные внутренние блоки</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/multizonalnye_vrf_sistemy/tonkie-kanalnye-bloki/">Тонкие канальные блоки</a>
                                    </li>
                                </ul>
                            </section>
                        </section>
                        <section class="ctm-main-menu-submenu-container">
                            <section class="ctm-main-menu-submenu-list-wrapper">
                                <img class="ctm-main-menu-submenu-list-cover" src="https://www.igc-aircon.com/upload/resize_cache/iblock/bca/60_60_1/bca9c7b4d611aa827ecd5df6f306c253.jpg">
                                <a href="/product/promyshlennye_konditsionery/">
                                <h2 class="ctm-main-menu-submenu-list-name">Промышленные кондиционеры</h2></a>
                                <ul class="ctm-main-menu-submenu-list">
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/promyshlennye_konditsionery/kanalnye_vnutrennie_bloki_bolshoy_moshchnosti/">Канальные внутренние блоки большой мощности</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/promyshlennye_konditsionery/kkb/">ККБ</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/promyshlennye_konditsionery/kolonnye_vnutrennie_bloki_bolshoy_moshchnosti/">Колонные внутренние блоки большой мощности</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/promyshlennye_konditsionery/mini_chillery/">Мини чиллеры</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/promyshlennye_konditsionery/modulnye_chillery/">Модульные чиллеры</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/promyshlennye_konditsionery/moshchnye_chillery_s_vintovym_kompressorom/">Мощные чиллеры с винтовым компрессором</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/promyshlennye_konditsionery/universalnye_naruzhnye_bloki/">Универсальные наружные блоки</a>
                                    </li>
                                    <li class="ctm-main-menu-submenu-list-item">
                                        <a class="ctm-main-menu-submenu-link" href="/product/promyshlennye_konditsionery/fankoyly/">Фанкойлы</a>
                                    </li>
                                </ul>
                            </section>
                        </section>
                    </section>
                </li>
                <li class="ctm-main-menu-list-item">
                    <a class="ctm-main-menu-list-item-link" href="/projects/">Наши объекты</a>
                    <ul class="ctm-main-menu-sublist">
                        <li class="ctm-main-menu-sublist-item">
                            <a class="ctm-main-menu-sublist-link" href="/projects/multizonalnye-sistemy/">Мультизональные системы</a>
                        </li>
                        <li class="ctm-main-menu-sublist-item">
                            <a class="ctm-main-menu-sublist-link" href="/projects/polupromyshlennye-sistemy/">Полупромышленные системы</a>
                        </li>
                        <li class="ctm-main-menu-sublist-item">
                            <a class="ctm-main-menu-sublist-link" href="/projects/chiller/">Чиллеры</a>
                        </li>
                    </ul>
                </li>
                <li class="ctm-main-menu-list-item">
                    <a class="ctm-main-menu-list-item-link" href="/dealer/">Стать дилером</a>
                </li>
                <li class="ctm-main-menu-list-item">
                    <a class="ctm-main-menu-list-item-link" href="/press/">Новости</a>
                </li>
                <li class="ctm-main-menu-list-item">
                    <a class="ctm-main-menu-list-item-link" href="/gde-kupit/">Где купить</a>
                </li>
                <li class="ctm-main-menu-list-item">
                    <a class="ctm-main-menu-list-item-link" href="/podderzhka/dokumentatsiya/">Поддержка</a>
                </li>
                <li class="ctm-main-menu-list-item">
                    <a class="ctm-main-menu-list-item-link" href="/contacts/">Контакты</a>
                </li>
            </ul>
        </section>
    </section>
</header>		</div>

		
					<div id="headerfixed">
				<div class="maxwidth-theme">
	<div class="logo-row v2 row margin0">

		<div class="inner-table-block menu-block menu-row">
			<div class="navs table-menu js-nav">
				<nav class="mega-menu sliced">
                    
    <div class="table-menu hght-100 catalog_icons_">
        <div class="marker-nav"></div>
        <table class="hght-100">
            <tbody><tr>
                <td class="menu-item hght-100 dropdown" style="visibility: visible;">
                    <div class="wrap hght-100 flex-row-c logo-in-table">
				<a href="/"><img src="/upload/VHeat/21b/21b0469be10ce5c153e5e4622d335a78.png" alt="igc-aircon" title="igc-aircon" /></a>					</div>

				</td>
                <td class="menu-item hght-100 dropdown" style="visibility: visible;">
                    <div class="wrap hght-100 flex-row-c">

                        <a class="dropdown-toggle hght-100 flex-row-vc lh-125 uppercase fs-14" href="/company/">
                            Компания							</a>
                        <span class="tail"></span>
                        <ul class="dropdown-menu  without_img shadow-light">
                            <li class=" count_3   ">

                                <a class="" href="/company/index.php" title="О компании">О компании</a>
                            </li>
                            <li class=" count_3   ">

                                <a class="" href="/company/history/" title="История">История</a>
                            </li>
                            <li class=" count_3   ">

                                <a class="" href="/company/partners/" title="Партнёры">Партнёры</a>
                            </li>
                            <li class=" count_3   ">

                                <a class="" href="/company/reviews/" title="Отзывы">Отзывы</a>
                            </li>
                            <li class=" count_3   ">

                                <a class="" href="/company/vacancy/" title="Вакансии">Вакансии</a>
                            </li>
                        </ul>
                    </div>
                </td>
                <td class="menu-item hght-100 dropdown wide_menu" style="visibility: visible;">
                    <div class="wrap hght-100 flex-row-c">
                        <a class="dropdown-toggle hght-100 flex-row-vc lh-125 uppercase fs-14" href="/product/">
                            Оборудование							</a>
                        <span class="tail"></span>
                        <div class="dropdown-menu   shadow-light">
                            <div class="maxwidth-theme">
                                <div class="bg-white wdt-100 narrow_shadow">
                                    <div class="col-lg-12 col-md-12 li_container mCustomScrollbar _mCS_1 mCS_no_scrollbar"><div id="mCSB_1" class="mCustomScrollBox mCS-light mCSB_vertical mCSB_inside" style="max-height: 0px;" tabindex="0"><div id="mCSB_1_container" class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" style="position:relative; top:0; left:0;" dir="ltr">
                                                <div class="row col-md-12">
                                                    <ul>
                                                        <li class="dropdown-submenu count_3  has_img col-md-4">

                                                            <div class="menu_img"><img src="/upload/resize_cache/iblock/6a8/60_60_1/6a81fe4e54f68127afd08d7ddc886733.jpg" alt="Бытовые сплит-системы" title="Бытовые сплит-системы" class="mCS_img_loaded"></div>

                                                            <div class="menu_container">
                                                                <a class="option-bold color-333 color-theme-hover" href="/product/bytovye_split_sistemy/" title="Бытовые сплит-системы">Бытовые сплит-системы<span class="arrow"><i></i></span></a>
                                                                <ul class="dropdown-menu toggle_menu">
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/bytovye_split_sistemy/split_sistemy/" title="Сплит-системы">Сплит-системы</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/bytovye_split_sistemy/multisplit_sistemy/" title="Мультисплит-системы">Мультисплит-системы</a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </li>
                                                        <li class="dropdown-submenu count_3  has_img col-md-4">

                                                            <div class="menu_img"><img src="/upload/resize_cache/iblock/3c6/60_60_1/3c61c4ea1471984917258f6219bb8bab.jpg" alt="Мультизональные VRF-системы" title="Мультизональные VRF-системы" class="mCS_img_loaded"></div>

                                                            <div class="menu_container">
                                                                <a class="option-bold color-333 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/" title="Мультизональные VRF-системы">Мультизональные VRF-системы<span class="arrow"><i></i></span></a>
                                                                <ul class="dropdown-menu toggle_menu">
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/vysokonapornye_kanalnye_vnutrennie_bloki/" title="Высоконапорные канальные внутренние блоки">Высоконапорные канальные внутренние блоки</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/individualnye-vrf/" title="Индивидуальные VRF">Индивидуальные VRF</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/kassetnye_vnutrennie_bloki/" title="Кассетные внутренние блоки">Кассетные внутренние блоки</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/modulnye_naruzhnye_bloki/" title="Модульные наружные блоки">Модульные наружные блоки</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/napolno_potolochnye_vnutrennie_bloki/" title="Напольно-потолочные внутренние блоки">Напольно-потолочные внутренние блоки</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/naruzhnye_bloki_mini/" title="Наружные блоки Mini">Наружные блоки Mini</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/nastennye_vnutrennie_bloki/" title="Настенные внутренние блоки">Настенные внутренние блоки</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/nizkonapornye_kanalnye_vnutrennie_bloki/" title="Низконапорные канальные внутренние блоки">Низконапорные канальные внутренние блоки</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/srednenapornye_kanalnye_vnutrennie_bloki/" title="Средненапорные канальные внутренние блоки">Средненапорные канальные внутренние блоки</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/tonkie-kanalnye-bloki/" title="Тонкие канальные блоки">Тонкие канальные блоки</a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </li>
                                                        <li class="dropdown-submenu count_3  has_img col-md-4">

                                                            <div class="menu_img"><img src="/upload/resize_cache/iblock/bca/60_60_1/bca9c7b4d611aa827ecd5df6f306c253.jpg" alt="Промышленные кондиционеры" title="Промышленные кондиционеры" class="mCS_img_loaded"></div>

                                                            <div class="menu_container">
                                                                <a class="option-bold color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/" title="Промышленные кондиционеры">Промышленные кондиционеры<span class="arrow"><i></i></span></a>
                                                                <ul class="dropdown-menu toggle_menu">
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/promyshlennye_konditsionery/kanalnye_vnutrennie_bloki_bolshoy_moshchnosti/" title="Канальные внутренние блоки большой мощности">Канальные внутренние блоки большой мощности</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/promyshlennye_konditsionery/kkb/" title="ККБ">ККБ</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/promyshlennye_konditsionery/kolonnye_vnutrennie_bloki_bolshoy_moshchnosti/" title="Колонные внутренние блоки большой мощности">Колонные внутренние блоки большой мощности</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/promyshlennye_konditsionery/mini_chillery/" title="Мини чиллеры">Мини чиллеры</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/promyshlennye_konditsionery/modulnye_chillery/" title="Модульные чиллеры">Модульные чиллеры</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/promyshlennye_konditsionery/moshchnye_chillery_s_vintovym_kompressorom/" title="Мощные чиллеры с винтовым компрессором">Мощные чиллеры с винтовым компрессором</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/promyshlennye_konditsionery/universalnye_naruzhnye_bloki/" title="Универсальные наружные блоки">Универсальные наружные блоки</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/" title="Фанкойлы">Фанкойлы</a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="row col-md-12">
                                                    <ul>
                                                        <li class="dropdown-submenu count_3  has_img col-md-4">

                                                            <div class="menu_img"><img src="/upload/resize_cache/iblock/063/60_60_1/0637b6cb969e1ee40ffd2b3b88bd4bb5.jpg" alt="Полупромышленные кондиционеры" title="Полупромышленные кондиционеры" class="mCS_img_loaded"></div>

                                                            <div class="menu_container">
                                                                <a class="option-bold color-333 color-theme-hover" href="/product/polupromyshlennye_konditsionery/" title="Полупромышленные кондиционеры">Полупромышленные кондиционеры<span class="arrow"><i></i></span></a>
                                                                <ul class="dropdown-menu toggle_menu">
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/polupromyshlennye_konditsionery/kanalnye_split_sistemy/" title="Канальные сплит-системы" style="white-space: normal;">Канальные сплит-системы</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/polupromyshlennye_konditsionery/kassetnye_split_sistemy/" title="Кассетные сплит-системы" style="white-space: normal;">Кассетные сплит-системы</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/polupromyshlennye_konditsionery/kolonnye_split_sistemy/" title="Колонные сплит-системы" style="white-space: normal;">Колонные сплит-системы</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/polupromyshlennye_konditsionery/napolno_potolochnye_split_sistemy/" title="Напольно-потолочные сплит-системы" style="white-space: normal;">Напольно-потолочные сплит-системы</a>
                                                                    </li>
                                                                    <li class="  ">
                                                                        <a class="color-666 color-theme-hover" href="/product/polupromyshlennye_konditsionery/naruzhnye-bloki/" title="Наружные блоки" style="white-space: normal;">Наружные блоки</a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div><div id="mCSB_1_scrollbar_vertical" class="mCSB_scrollTools mCSB_1_scrollbar mCS-light mCSB_scrollTools_vertical" style="display: none;"><div class="mCSB_draggerContainer"><div id="mCSB_1_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 30px; top: 0px; display: block; height: 402px; max-height: 422px;"><div class="mCSB_dragger_bar" style="line-height: 30px;"></div></div><div class="mCSB_draggerRail"></div></div></div></div></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td class="menu-item hght-100 dropdown" style="visibility: visible;">
                    <div class="wrap hght-100 flex-row-c">
                        <a class="dropdown-toggle hght-100 flex-row-vc lh-125 uppercase fs-14" href="/projects/">
                            Наши объекты							</a>
                        <span class="tail"></span>
                        <ul class="dropdown-menu  without_img shadow-light">
                            <li class=" count_3  has_img ">

                                <a class="" href="/projects/multizonalnye-sistemy/" title="Мультизональные системы">Мультизональные системы</a>
                            </li>
                            <li class=" count_3  has_img ">

                                <a class="" href="/projects/polupromyshlennye-sistemy/" title="Полупромышленные системы">Полупромышленные системы</a>
                            </li>
                            <li class=" count_3  has_img ">

                                <a class="" href="/projects/chiller/" title="Чиллеры">Чиллеры</a>
                            </li>
                        </ul>
                    </div>
                </td>
                <td class="menu-item hght-100" style="visibility: visible;">
                    <div class="wrap hght-100 flex-row-c">
                        <a class=" hght-100 flex-row-vc lh-125 uppercase fs-14" href="/dealer/">
                            Стать дилером							</a>

                    </div>
                </td>
                <td class="menu-item hght-100" style="visibility: visible;">
                    <div class="wrap hght-100 flex-row-c">
                        <a class=" hght-100 flex-row-vc lh-125 uppercase fs-14" href="/press/">
                            Новости							</a>

                    </div>
                </td>
                <td class="menu-item hght-100 fixed-menu-item-pred-pred-last" style="visibility: visible;">
                    <div class="wrap hght-100 flex-row-c">
                        <a class=" hght-100 flex-row-vc lh-125 uppercase fs-14" href="/gde-kupit/">
                            Где купить							</a>

                    </div>
                </td>
                <td class="menu-item hght-100 fixed-menu-item-pred-last" style="visibility: visible;">
                    <div class="wrap hght-100 flex-row-c">
                        <a class=" hght-100 flex-row-vc lh-125 uppercase fs-14" href="/podderzhka/dokumentatsiya/">
                            Поддержка							</a>

                    </div>
                </td>
                <td class="menu-item hght-100 fixed-menu-item-last" style="visibility: visible;">
                    <div class="wrap hght-100 flex-row-c">
                        <a class=" hght-100 flex-row-vc lh-125 uppercase fs-14" href="/contacts/">
                            Контакты							</a>

                    </div>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
				</nav>
			</div>
		</div>
		<div class="inner-table-block small-block inline-phone-show">
			<div class="phone-block" style="width:160px;">
						
								<div class="phone">
								<i class="svg inline  svg-inline-phone fill-theme" aria-hidden="true" ><svg id="Спрайт" xmlns="http://www.w3.org/2000/svg" width="14" height="56" viewBox="0 0 14 56">
  <defs>
    <style>
      .cls-1 {
        fill: #7a7c7f;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path id="Ellipse_13_copy" data-name="Ellipse 13 copy" class="cls-1" d="M11.5,46C9.035,46,5,39.09,5,35.5a6.5,6.5,0,0,1,13,0C18,39.09,14.027,46,11.5,46Zm0-15A4.5,4.5,0,0,0,7,35.5c0,2.485,3.046,8.5,4.5,8.5,1.485,0,4.5-6.015,4.5-8.5A4.5,4.5,0,0,0,11.5,31Z" transform="translate(-5 -5)"/>
  <path class="cls-1" d="M6,5H18a1,1,0,0,1,1,1V23a1,1,0,0,1-1,1H6a1,1,0,0,1-1-1V6A1,1,0,0,1,6,5ZM7,7H17V22H7V7Zm4,10h2v2H11V17Z" transform="translate(-5 -5)"/>
  <path class="cls-1" d="M18,61H6a1,1,0,0,1-1-1V52a1,1,0,0,1,1-1H18a1,1,0,0,1,1,1v8A1,1,0,0,1,18,61Zm-6-2L7,54v5h5ZM8.766,53L12,56.234,15.234,53M17,54l-5,5h5" transform="translate(-5 -5)"/>
</svg>
</i>				
				<a href="tel:+74952120722" class="fs-15 color-333 wgt-600">+7 (495) 212-07-22</a>
							</div>
									</div>
		</div>
		<div class="inner-table-block small-block inline-search-show" data-type_search="fixed">
			<div class="search-block wrap_icon" title="Поиск">
				<i class="svg inline  svg-inline-search big" aria-hidden="true" ><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M12.7609 14.2586C11.4245 15.2797 9.75459 15.8861 7.94299 15.8861C3.55625 15.8861 0 12.3299 0 7.94307C0 3.55622 3.55625 0 7.94299 0C12.3297 0 15.886 3.55622 15.886 7.94307C15.886 9.75463 15.2795 11.4245 14.2586 12.7608L17.6898 16.192C18.1034 16.6057 18.1034 17.2762 17.6898 17.6898C17.2761 18.1034 16.6057 18.1034 16.192 17.6898L12.7609 14.2586ZM13.7678 7.94307C13.7678 11.1601 11.16 13.768 7.94299 13.768C4.72597 13.768 2.11813 11.1601 2.11813 7.94307C2.11813 4.72609 4.72597 2.11815 7.94299 2.11815C11.16 2.11815 13.7678 4.72609 13.7678 7.94307Z" fill="#888888"/>
</svg>
</i>			</div>
		</div>
				<!--'start_frame_cache_basket-link1'-->		<!-- noindex -->
				<!-- /noindex -->
		<!--'end_frame_cache_basket-link1'-->												<div class="wrap_icon inner-table-block">
<a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://vk.com/igcaircon">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/icon-vk.svg" alt="vk">
                            </a>
                            <a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://www.youtube.com/channel/UCEU_d9DAPexWdPNLd8cSlYA">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/icon-youtube.svg" alt="youtube">
                            </a>							
                            <a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://t.me/igcaircon">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/tg.svg" alt="vk">
                            </a>
                            <a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://ok.ru/igcaircon">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ok.svg" alt="vk">
                            </a>
                            <a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://igcaircon.clients.site/">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ya-biz.svg" alt="vk">
                            </a>
                            <a style="vertical-align:-webkit-baseline-middle;margin-left:3px;;" class="ctm-footer-social-link" href="https://zen.yandex.ru/id/6229b31acbc61a17d6b94825">
                                <img style="height:auto;width:20px;" class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ya-zen.svg" alt="vk">
                            </a>
									</div>
	</div>
</div>

<div class="breadcrumb fixed">
	<div class="maxwidth-theme">
		<div class="bread_wrapper">
			<div class="col-md-12">
				<div class="breadcrumb_wrapper_fixed ">
				</div>
			</div>
		</div>
	</div>
</div>
			</div>
		
		
		<div id="mobileheader" class="visible-xs visible-sm">
			<div class="mobileheader-v1">
	<div class="burger">
		<i class="svg inline  svg-inline-burger dark" aria-hidden="true" ><svg width="20" height="14" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect width="20" height="2" rx="1" fill="white"/>
<rect y="6" width="20" height="2" rx="1" fill="white"/>
<rect y="12" width="20" height="2" rx="1" fill="white"/>
</svg>
</i>		<i class="svg inline  svg-inline-close dark" aria-hidden="true" ><svg id="Close.svg" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
  <defs>
    <style>
      .cls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path id="Rounded_Rectangle_114_copy_3" data-name="Rounded Rectangle 114 copy 3" class="cls-1" d="M334.411,138l6.3,6.3a1,1,0,0,1,0,1.414,0.992,0.992,0,0,1-1.408,0l-6.3-6.306-6.3,6.306a1,1,0,0,1-1.409-1.414l6.3-6.3-6.293-6.3a1,1,0,0,1,1.409-1.414l6.3,6.3,6.3-6.3A1,1,0,0,1,340.7,131.7Z" transform="translate(-325 -130)"/>
</svg>
</i>	</div>
  <section class="ctm-logo-wrapper">
    <div class="logo">
      <a href="/"><img src="/upload/VHeat/21b/21b0469be10ce5c153e5e4622d335a78.png" alt="igc-aircon" title="igc-aircon" /></a>    </div>
    <section class="ctm-logo-slogan">
      <span class="ctm-logo-slogan-text">Бытовые и промышленные</span>
      <span class="ctm-logo-slogan-text">климатические системы</span>
    </section>
  </section>
	<div class="right-icons">
		<div class="pull-right">
			<div class="wrap_icon">
				<button class="inline-search-show twosmallfont" title="Поиск">
					<i class="svg inline  svg-inline-search" aria-hidden="true" ><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M12.7609 14.2586C11.4245 15.2797 9.75459 15.8861 7.94299 15.8861C3.55625 15.8861 0 12.3299 0 7.94307C0 3.55622 3.55625 0 7.94299 0C12.3297 0 15.886 3.55622 15.886 7.94307C15.886 9.75463 15.2795 11.4245 14.2586 12.7608L17.6898 16.192C18.1034 16.6057 18.1034 17.2762 17.6898 17.6898C17.2761 18.1034 16.6057 18.1034 16.192 17.6898L12.7609 14.2586ZM13.7678 7.94307C13.7678 11.1601 11.16 13.768 7.94299 13.768C4.72597 13.768 2.11813 11.1601 2.11813 7.94307C2.11813 4.72609 4.72597 2.11815 7.94299 2.11815C11.16 2.11815 13.7678 4.72609 13.7678 7.94307Z" fill="#888888"/>
</svg>
</i>				</button>
			</div>
		</div>
	</div>
</div>
			<div id="mobilemenu" class="leftside">
				<div class="mobilemenu-v1 scroller">
	<div class="wrap">
    <section class="mobilemenu-v1-header">
        <section class="ctm-logo-wrapper">
        <div class="logo">
            <a href="/"><img src="/upload/VHeat/21b/21b0469be10ce5c153e5e4622d335a78.png" alt="igc-aircon" title="igc-aircon" /></a>        </div>
        <section class="ctm-logo-slogan">
          <span class="ctm-logo-slogan-text">Бытовые и промышленные</span>
          <span class="ctm-logo-slogan-text">климатические системы</span>
        </section>
      </section>
      <button class="inline-search-show twosmallfont" title="Поиск">
        <i class="svg inline  svg-inline-search" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.7609 14.2586C11.4245 15.2797 9.75459 15.8861 7.94299 15.8861C3.55625 15.8861 0 12.3299 0 7.94307C0 3.55622 3.55625 0 7.94299 0C12.3297 0 15.886 3.55622 15.886 7.94307C15.886 9.75463 15.2795 11.4245 14.2586 12.7608L17.6898 16.192C18.1034 16.6057 18.1034 17.2762 17.6898 17.6898C17.2761 18.1034 16.6057 18.1034 16.192 17.6898L12.7609 14.2586ZM13.7678 7.94307C13.7678 11.1601 11.16 13.768 7.94299 13.768C4.72597 13.768 2.11813 11.1601 2.11813 7.94307C2.11813 4.72609 4.72597 2.11815 7.94299 2.11815C11.16 2.11815 13.7678 4.72609 13.7678 7.94307Z" fill="#888888"></path>
          </svg>
        </i>
      </button>
    </section>
			<div class="menu top">
		<ul class="top">
															<li>
					<a class="color-333 color-theme-hover parent" href="/company/" title="Компания">
						<span>Компания</span>
													<span class="arrow"><i class="svg svg_triangle_right"></i></span>
											</a>
											<ul class="dropdown">
							<li class="menu_back"><a href="" class="color-333 color-theme-hover" rel="nofollow"><i class="svg inline  svg-inline-arrow-back" aria-hidden="true" ><svg xmlns="http://www.w3.org/2000/svg" width="17" height="12" viewBox="0 0 17 12">
  <defs>
    <style>
      .rcls-1 {
        fill: #fff;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 3 copy" class="rcls-1" d="M253.052,4840.24a0.747,0.747,0,0,0,.026.13c0,0.01.014,0.02,0.019,0.03a0.967,0.967,0,0,0,.2.3l4.992,5a1,1,0,0,0,1.414-1.42l-3.287-3.29H269a1.005,1.005,0,0,0,0-2.01H256.416l3.287-3.29a1.006,1.006,0,0,0,0-1.42,0.983,0.983,0,0,0-1.414,0l-4.992,4.99a1.01,1.01,0,0,0-.2.31c0,0.01-.014.01-0.019,0.02a1.147,1.147,0,0,0-.026.14A0.651,0.651,0,0,0,253.052,4840.24Z" transform="translate(-253 -4834)"/>
</svg>
</i>Назад</a></li>
							<li class="menu_title"><a href="/company/">Компания</a></li>
																															<li>
									<a class="color-333 color-theme-hover" href="/company/index.php" title="О компании">
										<span>О компании</span>
																			</a>
																	</li>
																															<li>
									<a class="color-333 color-theme-hover" href="/company/history/" title="История">
										<span>История</span>
																			</a>
																	</li>
																															<li>
									<a class="color-333 color-theme-hover" href="/company/partners/" title="Партнёры">
										<span>Партнёры</span>
																			</a>
																	</li>
																															<li>
									<a class="color-333 color-theme-hover" href="/company/reviews/" title="Отзывы">
										<span>Отзывы</span>
																			</a>
																	</li>
																															<li>
									<a class="color-333 color-theme-hover" href="/company/vacancy/" title="Вакансии">
										<span>Вакансии</span>
																			</a>
																	</li>
													</ul>
									</li>
															<li>
					<a class="color-333 color-theme-hover parent" href="/product/" title="Оборудование">
						<span>Оборудование</span>
													<span class="arrow"><i class="svg svg_triangle_right"></i></span>
											</a>
											<ul class="dropdown">
							<li class="menu_back"><a href="" class="color-333 color-theme-hover" rel="nofollow"><i class="svg inline  svg-inline-arrow-back" aria-hidden="true" ><svg xmlns="http://www.w3.org/2000/svg" width="17" height="12" viewBox="0 0 17 12">
  <defs>
    <style>
      .rcls-1 {
        fill: #fff;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 3 copy" class="rcls-1" d="M253.052,4840.24a0.747,0.747,0,0,0,.026.13c0,0.01.014,0.02,0.019,0.03a0.967,0.967,0,0,0,.2.3l4.992,5a1,1,0,0,0,1.414-1.42l-3.287-3.29H269a1.005,1.005,0,0,0,0-2.01H256.416l3.287-3.29a1.006,1.006,0,0,0,0-1.42,0.983,0.983,0,0,0-1.414,0l-4.992,4.99a1.01,1.01,0,0,0-.2.31c0,0.01-.014.01-0.019,0.02a1.147,1.147,0,0,0-.026.14A0.651,0.651,0,0,0,253.052,4840.24Z" transform="translate(-253 -4834)"/>
</svg>
</i>Назад</a></li>
							<li class="menu_title"><a href="/product/">Оборудование</a></li>
																															<li>
									<a class="color-333 color-theme-hover parent" href="/product/bytovye_split_sistemy/" title="Бытовые сплит-системы">
										<span>Бытовые сплит-системы</span>
																					<span class="arrow"><i class="svg svg_triangle_right"></i></span>
																			</a>
																			<ul class="dropdown">
											<li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg inline  svg-inline-arrow-back" aria-hidden="true" ><svg xmlns="http://www.w3.org/2000/svg" width="17" height="12" viewBox="0 0 17 12">
  <defs>
    <style>
      .cls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 3 copy" class="cls-1" d="M253.052,4840.24a0.747,0.747,0,0,0,.026.13c0,0.01.014,0.02,0.019,0.03a0.967,0.967,0,0,0,.2.3l4.992,5a1,1,0,0,0,1.414-1.42l-3.287-3.29H269a1.005,1.005,0,0,0,0-2.01H256.416l3.287-3.29a1.006,1.006,0,0,0,0-1.42,0.983,0.983,0,0,0-1.414,0l-4.992,4.99a1.01,1.01,0,0,0-.2.31c0,0.01-.014.01-0.019,0.02a1.147,1.147,0,0,0-.026.14A0.651,0.651,0,0,0,253.052,4840.24Z" transform="translate(-253 -4834)"/>
</svg>
</i>Назад</a></li>
											<li class="menu_title"><a href="/product/bytovye_split_sistemy/">Бытовые сплит-системы</a></li>
																																															<li>
													<a class="color-333 color-theme-hover parent" href="/product/bytovye_split_sistemy/split_sistemy/" title="Сплит-системы">
														<span>Сплит-системы</span>
																													<span class="arrow"><i class="svg svg_triangle_right"></i></span>
																											</a>
																											<ul class="dropdown">
															<li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg inline  svg-inline-arrow-back" aria-hidden="true" ><svg xmlns="http://www.w3.org/2000/svg" width="17" height="12" viewBox="0 0 17 12">
  <defs>
    <style>
      .cls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 3 copy" class="cls-1" d="M253.052,4840.24a0.747,0.747,0,0,0,.026.13c0,0.01.014,0.02,0.019,0.03a0.967,0.967,0,0,0,.2.3l4.992,5a1,1,0,0,0,1.414-1.42l-3.287-3.29H269a1.005,1.005,0,0,0,0-2.01H256.416l3.287-3.29a1.006,1.006,0,0,0,0-1.42,0.983,0.983,0,0,0-1.414,0l-4.992,4.99a1.01,1.01,0,0,0-.2.31c0,0.01-.014.01-0.019,0.02a1.147,1.147,0,0,0-.026.14A0.651,0.651,0,0,0,253.052,4840.24Z" transform="translate(-253 -4834)"/>
</svg>
</i>Назад</a></li>
															<li class="menu_title"><a href="/product/bytovye_split_sistemy/split_sistemy/">Сплит-системы</a></li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/bytovye_split_sistemy/split_sistemy/seriya_magic/" title="Серия Magic">
																		<span>Серия Magic</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/bytovye_split_sistemy/split_sistemy/seriya_silver/" title="Серия Silver DC Invertor">
																		<span>Серия Silver DC Invertor</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/bytovye_split_sistemy/split_sistemy/seriya-fresco/" title="Серия Fresco">
																		<span>Серия Fresco</span>
																	</a>
																</li>
																													</ul>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover parent" href="/product/bytovye_split_sistemy/multisplit_sistemy/" title="Мультисплит-системы">
														<span>Мультисплит-системы</span>
																													<span class="arrow"><i class="svg svg_triangle_right"></i></span>
																											</a>
																											<ul class="dropdown">
															<li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg inline  svg-inline-arrow-back" aria-hidden="true" ><svg xmlns="http://www.w3.org/2000/svg" width="17" height="12" viewBox="0 0 17 12">
  <defs>
    <style>
      .cls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 3 copy" class="cls-1" d="M253.052,4840.24a0.747,0.747,0,0,0,.026.13c0,0.01.014,0.02,0.019,0.03a0.967,0.967,0,0,0,.2.3l4.992,5a1,1,0,0,0,1.414-1.42l-3.287-3.29H269a1.005,1.005,0,0,0,0-2.01H256.416l3.287-3.29a1.006,1.006,0,0,0,0-1.42,0.983,0.983,0,0,0-1.414,0l-4.992,4.99a1.01,1.01,0,0,0-.2.31c0,0.01-.014.01-0.019,0.02a1.147,1.147,0,0,0-.026.14A0.651,0.651,0,0,0,253.052,4840.24Z" transform="translate(-253 -4834)"/>
</svg>
</i>Назад</a></li>
															<li class="menu_title"><a href="/product/bytovye_split_sistemy/multisplit_sistemy/">Мультисплит-системы</a></li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/bytovye_split_sistemy/multisplit_sistemy/kanalnye_vnutrennie_bloki/" title="Канальные внутренние блоки">
																		<span>Канальные внутренние блоки</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/bytovye_split_sistemy/multisplit_sistemy/kassetnye_vnutrennie_bloki187/" title="Кассетные внутренние блоки">
																		<span>Кассетные внутренние блоки</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/bytovye_split_sistemy/multisplit_sistemy/napolno_potolochnye_vnutrennie_bloki188/" title="Напольно-потолочные внутренние блоки">
																		<span>Напольно-потолочные внутренние блоки</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/bytovye_split_sistemy/multisplit_sistemy/nastennye_vnutrennie_bloki185/" title="Настенные внутренние блоки">
																		<span>Настенные внутренние блоки</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/bytovye_split_sistemy/multisplit_sistemy/universalnye_naruzhnye_bloki189/" title="Универсальные наружные блоки">
																		<span>Универсальные наружные блоки</span>
																	</a>
																</li>
																													</ul>
																									</li>
																					</ul>
																	</li>
																															<li>
									<a class="color-333 color-theme-hover parent" href="/product/multizonalnye_vrf_sistemy/" title="Мультизональные VRF-системы">
										<span>Мультизональные VRF-системы</span>
																					<span class="arrow"><i class="svg svg_triangle_right"></i></span>
																			</a>
																			<ul class="dropdown">
											<li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg inline  svg-inline-arrow-back" aria-hidden="true" ><svg xmlns="http://www.w3.org/2000/svg" width="17" height="12" viewBox="0 0 17 12">
  <defs>
    <style>
      .cls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 3 copy" class="cls-1" d="M253.052,4840.24a0.747,0.747,0,0,0,.026.13c0,0.01.014,0.02,0.019,0.03a0.967,0.967,0,0,0,.2.3l4.992,5a1,1,0,0,0,1.414-1.42l-3.287-3.29H269a1.005,1.005,0,0,0,0-2.01H256.416l3.287-3.29a1.006,1.006,0,0,0,0-1.42,0.983,0.983,0,0,0-1.414,0l-4.992,4.99a1.01,1.01,0,0,0-.2.31c0,0.01-.014.01-0.019,0.02a1.147,1.147,0,0,0-.026.14A0.651,0.651,0,0,0,253.052,4840.24Z" transform="translate(-253 -4834)"/>
</svg>
</i>Назад</a></li>
											<li class="menu_title"><a href="/product/multizonalnye_vrf_sistemy/">Мультизональные VRF-системы</a></li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/vysokonapornye_kanalnye_vnutrennie_bloki/" title="Высоконапорные канальные внутренние блоки">
														<span>Высоконапорные канальные внутренние блоки</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/individualnye-vrf/" title="Индивидуальные VRF">
														<span>Индивидуальные VRF</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/kassetnye_vnutrennie_bloki/" title="Кассетные внутренние блоки">
														<span>Кассетные внутренние блоки</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/modulnye_naruzhnye_bloki/" title="Модульные наружные блоки">
														<span>Модульные наружные блоки</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/napolno_potolochnye_vnutrennie_bloki/" title="Напольно-потолочные внутренние блоки">
														<span>Напольно-потолочные внутренние блоки</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/naruzhnye_bloki_mini/" title="Наружные блоки Mini">
														<span>Наружные блоки Mini</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/nastennye_vnutrennie_bloki/" title="Настенные внутренние блоки">
														<span>Настенные внутренние блоки</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/nizkonapornye_kanalnye_vnutrennie_bloki/" title="Низконапорные канальные внутренние блоки">
														<span>Низконапорные канальные внутренние блоки</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/srednenapornye_kanalnye_vnutrennie_bloki/" title="Средненапорные канальные внутренние блоки">
														<span>Средненапорные канальные внутренние блоки</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/multizonalnye_vrf_sistemy/tonkie-kanalnye-bloki/" title="Тонкие канальные блоки">
														<span>Тонкие канальные блоки</span>
																											</a>
																									</li>
																					</ul>
																	</li>
																															<li>
									<a class="color-333 color-theme-hover parent" href="/product/promyshlennye_konditsionery/" title="Промышленные кондиционеры">
										<span>Промышленные кондиционеры</span>
																					<span class="arrow"><i class="svg svg_triangle_right"></i></span>
																			</a>
																			<ul class="dropdown">
											<li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg inline  svg-inline-arrow-back" aria-hidden="true" ><svg xmlns="http://www.w3.org/2000/svg" width="17" height="12" viewBox="0 0 17 12">
  <defs>
    <style>
      .cls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 3 copy" class="cls-1" d="M253.052,4840.24a0.747,0.747,0,0,0,.026.13c0,0.01.014,0.02,0.019,0.03a0.967,0.967,0,0,0,.2.3l4.992,5a1,1,0,0,0,1.414-1.42l-3.287-3.29H269a1.005,1.005,0,0,0,0-2.01H256.416l3.287-3.29a1.006,1.006,0,0,0,0-1.42,0.983,0.983,0,0,0-1.414,0l-4.992,4.99a1.01,1.01,0,0,0-.2.31c0,0.01-.014.01-0.019,0.02a1.147,1.147,0,0,0-.026.14A0.651,0.651,0,0,0,253.052,4840.24Z" transform="translate(-253 -4834)"/>
</svg>
</i>Назад</a></li>
											<li class="menu_title"><a href="/product/promyshlennye_konditsionery/">Промышленные кондиционеры</a></li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/kanalnye_vnutrennie_bloki_bolshoy_moshchnosti/" title="Канальные внутренние блоки большой мощности">
														<span>Канальные внутренние блоки большой мощности</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/kkb/" title="ККБ">
														<span>ККБ</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/kolonnye_vnutrennie_bloki_bolshoy_moshchnosti/" title="Колонные внутренние блоки большой мощности">
														<span>Колонные внутренние блоки большой мощности</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/mini_chillery/" title="Мини чиллеры">
														<span>Мини чиллеры</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/modulnye_chillery/" title="Модульные чиллеры">
														<span>Модульные чиллеры</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/moshchnye_chillery_s_vintovym_kompressorom/" title="Мощные чиллеры с винтовым компрессором">
														<span>Мощные чиллеры с винтовым компрессором</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/universalnye_naruzhnye_bloki/" title="Универсальные наружные блоки">
														<span>Универсальные наружные блоки</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover parent" href="/product/promyshlennye_konditsionery/fankoyly/" title="Фанкойлы">
														<span>Фанкойлы</span>
																													<span class="arrow"><i class="svg svg_triangle_right"></i></span>
																											</a>
																											<ul class="dropdown">
															<li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg inline  svg-inline-arrow-back" aria-hidden="true" ><svg xmlns="http://www.w3.org/2000/svg" width="17" height="12" viewBox="0 0 17 12">
  <defs>
    <style>
      .cls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 3 copy" class="cls-1" d="M253.052,4840.24a0.747,0.747,0,0,0,.026.13c0,0.01.014,0.02,0.019,0.03a0.967,0.967,0,0,0,.2.3l4.992,5a1,1,0,0,0,1.414-1.42l-3.287-3.29H269a1.005,1.005,0,0,0,0-2.01H256.416l3.287-3.29a1.006,1.006,0,0,0,0-1.42,0.983,0.983,0,0,0-1.414,0l-4.992,4.99a1.01,1.01,0,0,0-.2.31c0,0.01-.014.01-0.019,0.02a1.147,1.147,0,0,0-.026.14A0.651,0.651,0,0,0,253.052,4840.24Z" transform="translate(-253 -4834)"/>
</svg>
</i>Назад</a></li>
															<li class="menu_title"><a href="/product/promyshlennye_konditsionery/fankoyly/">Фанкойлы</a></li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/kassetnye_360_kh_seriya/" title="Кассетные 360° Х серия">
																		<span>Кассетные 360° Х серия</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/kassetnye_4kh_potochnye_2kh_trubnye/" title="Кассетные 4х-поточные 2х-трубные">
																		<span>Кассетные 4х-поточные 2х-трубные</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/kassetnye_4kh_potochnye_2kh_trubnye_kompaktnye/" title="Кассетные 4х-поточные 2х-трубные компактные">
																		<span>Кассетные 4х-поточные 2х-трубные компактные</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/kassetnye_4kh_potochnye_4kh_trubnye/" title="Кассетные 4х-поточные 4х-трубные">
																		<span>Кассетные 4х-поточные 4х-трубные</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/kassetnye_odnopotochnye/" title="Кассетные однопоточные">
																		<span>Кассетные однопоточные</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/nastennye_fankoyly/" title="Настенные фанкойлы">
																		<span>Настенные фанкойлы</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/srednenapornye_kanalnye_kh_seriya/" title="Средненапорные канальные Х серия">
																		<span>Средненапорные канальные Х серия</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/nizkonapornye_kanalnye/" title="Низконапорные канальные">
																		<span>Низконапорные канальные</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/vysokonapornye_kanalnye/" title="Высоконапорные канальные">
																		<span>Высоконапорные канальные</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/srednenapornye_kanalnye/" title="Средненапорные канальные">
																		<span>Средненапорные канальные</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/napolno_potolochnye_beskorpusnye/" title="Напольно-потолочные бескорпусные">
																		<span>Напольно-потолочные бескорпусные</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/napolno_potolochnye_s_zaborom_vozdukha_snizu/" title="Напольно-потолочные с забором воздуха снизу">
																		<span>Напольно-потолочные с забором воздуха снизу</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/napolno_potolochnye_s_zaborom_vozdukha_speredi/" title="Напольно-потолочные с забором воздуха спереди">
																		<span>Напольно-потолочные с забором воздуха спереди</span>
																	</a>
																</li>
																															<li>
																	<a class="color-333 color-theme-hover" href="/product/promyshlennye_konditsionery/fankoyly/kanalnye-4kh-trubnye/" title="Канальные 4х-трубные">
																		<span>Канальные 4х-трубные</span>
																	</a>
																</li>
																													</ul>
																									</li>
																					</ul>
																	</li>
																															<li>
									<a class="color-333 color-theme-hover parent" href="/product/polupromyshlennye_konditsionery/" title="Полупромышленные кондиционеры">
										<span>Полупромышленные кондиционеры</span>
																					<span class="arrow"><i class="svg svg_triangle_right"></i></span>
																			</a>
																			<ul class="dropdown">
											<li class="menu_back"><a href="" class="dark-color" rel="nofollow"><i class="svg inline  svg-inline-arrow-back" aria-hidden="true" ><svg xmlns="http://www.w3.org/2000/svg" width="17" height="12" viewBox="0 0 17 12">
  <defs>
    <style>
      .cls-1 {
        fill: #222;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 3 copy" class="cls-1" d="M253.052,4840.24a0.747,0.747,0,0,0,.026.13c0,0.01.014,0.02,0.019,0.03a0.967,0.967,0,0,0,.2.3l4.992,5a1,1,0,0,0,1.414-1.42l-3.287-3.29H269a1.005,1.005,0,0,0,0-2.01H256.416l3.287-3.29a1.006,1.006,0,0,0,0-1.42,0.983,0.983,0,0,0-1.414,0l-4.992,4.99a1.01,1.01,0,0,0-.2.31c0,0.01-.014.01-0.019,0.02a1.147,1.147,0,0,0-.026.14A0.651,0.651,0,0,0,253.052,4840.24Z" transform="translate(-253 -4834)"/>
</svg>
</i>Назад</a></li>
											<li class="menu_title"><a href="/product/polupromyshlennye_konditsionery/">Полупромышленные кондиционеры</a></li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/polupromyshlennye_konditsionery/kanalnye_split_sistemy/" title="Канальные сплит-системы">
														<span>Канальные сплит-системы</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/polupromyshlennye_konditsionery/kassetnye_split_sistemy/" title="Кассетные сплит-системы">
														<span>Кассетные сплит-системы</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/polupromyshlennye_konditsionery/kolonnye_split_sistemy/" title="Колонные сплит-системы">
														<span>Колонные сплит-системы</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/polupromyshlennye_konditsionery/napolno_potolochnye_split_sistemy/" title="Напольно-потолочные сплит-системы">
														<span>Напольно-потолочные сплит-системы</span>
																											</a>
																									</li>
																																															<li>
													<a class="color-333 color-theme-hover" href="/product/polupromyshlennye_konditsionery/naruzhnye-bloki/" title="Наружные блоки">
														<span>Наружные блоки</span>
																											</a>
																									</li>
																					</ul>
																	</li>
													</ul>
									</li>
															<li>
					<a class="color-333 color-theme-hover parent" href="/projects/" title="Наши объекты">
						<span>Наши объекты</span>
													<span class="arrow"><i class="svg svg_triangle_right"></i></span>
											</a>
											<ul class="dropdown">
							<li class="menu_back"><a href="" class="color-333 color-theme-hover" rel="nofollow"><i class="svg inline  svg-inline-arrow-back" aria-hidden="true" ><svg xmlns="http://www.w3.org/2000/svg" width="17" height="12" viewBox="0 0 17 12">
  <defs>
    <style>
      .rcls-1 {
        fill: #fff;
        fill-rule: evenodd;
      }
    </style>
  </defs>
  <path data-name="Rounded Rectangle 3 copy" class="rcls-1" d="M253.052,4840.24a0.747,0.747,0,0,0,.026.13c0,0.01.014,0.02,0.019,0.03a0.967,0.967,0,0,0,.2.3l4.992,5a1,1,0,0,0,1.414-1.42l-3.287-3.29H269a1.005,1.005,0,0,0,0-2.01H256.416l3.287-3.29a1.006,1.006,0,0,0,0-1.42,0.983,0.983,0,0,0-1.414,0l-4.992,4.99a1.01,1.01,0,0,0-.2.31c0,0.01-.014.01-0.019,0.02a1.147,1.147,0,0,0-.026.14A0.651,0.651,0,0,0,253.052,4840.24Z" transform="translate(-253 -4834)"/>
</svg>
</i>Назад</a></li>
							<li class="menu_title"><a href="/projects/">Наши объекты</a></li>
																															<li>
									<a class="color-333 color-theme-hover" href="/projects/multizonalnye-sistemy/" title="Мультизональные системы">
										<span>Мультизональные системы</span>
																			</a>
																	</li>
																															<li>
									<a class="color-333 color-theme-hover" href="/projects/polupromyshlennye-sistemy/" title="Полупромышленные системы">
										<span>Полупромышленные системы</span>
																			</a>
																	</li>
																															<li>
									<a class="color-333 color-theme-hover" href="/projects/chiller/" title="Чиллеры">
										<span>Чиллеры</span>
																			</a>
																	</li>
													</ul>
									</li>
															<li>
					<a class="color-333 color-theme-hover" href="/dealer/" title="Стать дилером">
						<span>Стать дилером</span>
											</a>
									</li>
															<li>
					<a class="color-333 color-theme-hover" href="/press/" title="Новости">
						<span>Новости</span>
											</a>
									</li>
															<li>
					<a class="color-333 color-theme-hover" href="/gde-kupit/" title="Где купить">
						<span>Где купить</span>
											</a>
									</li>
															<li>
					<a class="color-333 color-theme-hover" href="/podderzhka/dokumentatsiya/" title="Поддержка">
						<span>Поддержка</span>
											</a>
									</li>
															<li>
					<a class="color-333 color-theme-hover" href="/contacts/" title="Контакты">
						<span>Контакты</span>
											</a>
									</li>
					</ul>
	</div>
      <div class="menu middle">
        <ul>
		  </ul>
        <ul>
          <li>
    <a class="btn btn--red btn-consultation feedback_call_click callback-block animate-load" href="#" data-event="jqm" data-param-id="55" data-name="callback">Получить консультацию</a>
			</li>
          <li>
            <a href="tel:+74952120722" class="color-333 color-theme-hover parent">
              <span>+7 (495) 212-07-22</span>
            </a>
          </li>
          <li>
            <!--<a href="tel:+74952121411" class="color-333 color-theme-hover parent">
              <span>+7 (495) 212-14-11</span>
            </a>-->
          </li>
        </ul>
      </div>
			</div>
</div>
			</div>
		</div>

		<div class="body  hover_">
			<div class="body_media"></div>

			<div role="main" class="main banner-auto">
				
				<div class="container  with_error">
											<div class="row">
															<div class="maxwidth-theme">
																						<div class="col-md-12 col-sm-12 col-xs-12 content-md">
																	<div class="page404">
	<div class="row">
		<div class="col-md-6 hidden-xs hidden-sm">
			<div class="wrapper left_unfound_block">
				<svg xmlns="http://www.w3.org/2000/svg" width="480" height="261" viewBox="0 0 480 261" fill="none">
				<path d="M143 53.5C143 52.6716 143.672 52 144.5 52H164.5C165.328 52 166 52.6716 166 53.5C166 54.3284 165.328 55 164.5 55H144.5C143.672 55 143 54.3284 143 53.5Z" fill="#B4C7E5"/>
				<path d="M176 53.5C176 52.6716 176.672 52 177.5 52H258.5C259.328 52 260 52.6716 260 53.5C260 54.3284 259.328 55 258.5 55H177.5C176.672 55 176 54.3284 176 53.5Z" fill="#B4C7E5"/>
				<path d="M156 71.5C156 70.6716 156.672 70 157.5 70H258.5C259.328 70 260 70.6716 260 71.5C260 72.3284 259.328 73 258.5 73H157.5C156.672 73 156 72.3284 156 71.5Z" fill="#B4C7E5"/>
				<path d="M178 89.5C178 88.6716 178.672 88 179.5 88H258.5C259.328 88 260 88.6716 260 89.5C260 90.3284 259.328 91 258.5 91H179.5C178.672 91 178 90.3284 178 89.5Z" fill="#B4C7E5"/>
				<path d="M178 107.5C178 106.672 178.672 106 179.5 106H258.5C259.328 106 260 106.672 260 107.5C260 108.328 259.328 109 258.5 109H179.5C178.672 109 178 108.328 178 107.5Z" fill="#B4C7E5"/>
				<path d="M215 142.5C215 141.672 215.672 141 216.5 141H258.5C259.328 141 260 141.672 260 142.5C260 143.328 259.328 144 258.5 144H216.5C215.672 144 215 143.328 215 142.5Z" fill="#B4C7E5"/>
				<path d="M178 142.5C178 141.672 178.672 141 179.5 141H203.5C204.328 141 205 141.672 205 142.5C205 143.328 204.328 144 203.5 144H179.5C178.672 144 178 143.328 178 142.5Z" fill="#B4C7E5"/>
				<path d="M179.5 159C178.672 159 178 159.672 178 160.5C178 161.328 178.672 162 179.5 162H283.5C284.328 162 285 161.328 285 160.5C285 159.672 284.328 159 283.5 159H179.5Z" fill="#B4C7E5"/>
				<path d="M45 191H42V234C42 237.314 44.6863 240 48 240H140C143.314 240 146 237.314 146 234V191H143V234C143 235.657 141.657 237 140 237H48C46.3431 237 45 235.657 45 234V191Z" fill="#B4C7E5"/>
				<path d="M94 253C96.2091 253 98 251.209 98 249C98 246.791 96.2091 245 94 245C91.7909 245 90 246.791 90 249C90 251.209 91.7909 253 94 253Z" fill="#B4C7E5"/>
				<path d="M55 210.5C55 209.672 55.6716 209 56.5 209H88.5C89.3284 209 90 209.672 90 210.5C90 211.328 89.3284 212 88.5 212H56.5C55.6716 212 55 211.328 55 210.5Z" fill="#B4C7E5"/>
				<path d="M55 218.5C55 217.672 55.6716 217 56.5 217H106.5C107.328 217 108 217.672 108 218.5C108 219.328 107.328 220 106.5 220H56.5C55.6716 220 55 219.328 55 218.5Z" fill="#B4C7E5"/>
				<path d="M55 226.5C55 225.672 55.6716 225 56.5 225H72.5C73.3284 225 74 225.672 74 226.5C74 227.328 73.3284 228 72.5 228H56.5C55.6716 228 55 227.328 55 226.5Z" fill="#B4C7E5"/>
				<path d="M388 154C385.791 154 384 155.791 384 158V194H387V158C387 157.448 387.448 157 388 157H434C434.552 157 435 157.448 435 158V194H438V158C438 155.791 436.209 154 434 154H388Z" fill="#B4C7E5"/>
				<path d="M416 166.5C416 165.672 416.672 165 417.5 165H426.5C427.328 165 428 165.672 428 166.5C428 167.328 427.328 168 426.5 168H417.5C416.672 168 416 167.328 416 166.5Z" fill="#B4C7E5"/>
				<path d="M405.5 171C404.672 171 404 171.672 404 172.5C404 173.328 404.672 174 405.5 174H426.5C427.328 174 428 173.328 428 172.5C428 171.672 427.328 171 426.5 171H405.5Z" fill="#B4C7E5"/>
				<path d="M413 178.5C413 177.672 413.672 177 414.5 177H426.5C427.328 177 428 177.672 428 178.5C428 179.328 427.328 180 426.5 180H414.5C413.672 180 413 179.328 413 178.5Z" fill="#B4C7E5"/>
				<path d="M411 254C413.209 254 415 252.209 415 250C415 247.791 413.209 246 411 246C408.791 246 407 247.791 407 250C407 252.209 408.791 254 411 254Z" fill="#B4C7E5"/>
				<path fill-rule="evenodd" clip-rule="evenodd" d="M103 0C98.0294 0 94 4.02945 94 9V95H42C36.4772 95 32 99.4771 32 105V251C32 253.725 33.0903 256.196 34.8586 258H1.5C0.67157 258 0 258.672 0 259.5C0 260.328 0.67157 261 1.5 261H478.5C479.328 261 480 260.328 480 259.5C480 258.672 479.328 258 478.5 258H445.708C447.133 256.408 448 254.305 448 252V153C448 148.029 443.971 144 439 144H412V9C412 4.02945 407.971 0 403 0H103ZM215.556 258H290.84C287.063 245.138 284.489 231.761 283.249 218H223.148C221.908 231.761 219.334 245.138 215.556 258ZM374 215V187H156V215H374ZM220.135 218C218.876 231.77 216.262 245.148 212.427 258H153.141C154.91 256.196 156 253.725 156 251V218H220.135ZM376.292 258H293.97C290.135 245.148 287.52 231.77 286.261 218H374V252C374 254.305 374.867 256.408 376.292 258ZM409 144V9C409 5.68628 406.314 3 403 3H103C99.6863 3 97 5.68628 97 9V95H107V18C107 15.2386 109.239 13 112 13H394C396.761 13 399 15.2386 399 18V144H409ZM396 144V18C396 16.8954 395.105 16 394 16H112C110.895 16 110 16.8954 110 18V95H146C151.523 95 156 99.4771 156 105V184H374V153C374 148.029 378.029 144 383 144H396ZM35 105C35 101.134 38.134 98 42 98H146C149.866 98 153 101.134 153 105V251C153 254.866 149.866 258 146 258H42C38.134 258 35 254.866 35 251V105ZM445 252C445 255.314 442.314 258 439 258H383C379.686 258 377 255.314 377 252V153C377 149.686 379.686 147 383 147H439C442.314 147 445 149.686 445 153V252Z" fill="#B4C7E5"/>
				<path class="fill-theme" fill-rule="evenodd" clip-rule="evenodd" d="M282 83C282 57.5949 302.595 37 328 37C353.405 37 374 57.5949 374 83C374 108.405 353.405 129 328 129C302.595 129 282 108.405 282 83ZM314.96 70.0604C315.546 69.4746 316.496 69.4746 317.081 70.0604L327.92 80.8994L338.759 70.0608C339.345 69.475 340.295 69.475 340.88 70.0608C341.466 70.6466 341.466 71.5963 340.88 72.1821L330.042 83.0209L340.88 93.8598C341.466 94.4456 341.466 95.3953 340.88 95.9811C340.295 96.5669 339.345 96.5669 338.759 95.9811L327.92 85.1421L317.081 95.9807C316.496 96.5665 315.546 96.5665 314.96 95.9807C314.374 95.3949 314.374 94.4452 314.96 93.8594L325.799 83.0206L314.96 72.1817C314.374 71.5959 314.374 70.6462 314.96 70.0604Z" fill="#216EF0"/>
				<path class="fill-theme" fill-rule="evenodd" clip-rule="evenodd" d="M42 111C42 107.686 44.6863 105 48 105H140C143.314 105 146 107.686 146 111V193C146 196.314 143.314 199 140 199H48C44.6863 199 42 196.314 42 193V111ZM81.4262 140.426C81.9946 139.858 82.916 139.858 83.4843 140.426L94.0002 150.942L104.516 140.427C105.084 139.858 106.005 139.858 106.574 140.427C107.142 140.995 107.142 141.916 106.574 142.485L96.058 153L106.574 163.516C107.142 164.084 107.142 165.005 106.574 165.574C106.005 166.142 105.084 166.142 104.516 165.574L93.9998 155.058L83.4843 165.573C82.916 166.142 81.9946 166.142 81.4262 165.573C80.8579 165.005 80.8579 164.084 81.4262 163.515L91.942 153L81.4262 142.484C80.8579 141.916 80.8579 140.995 81.4262 140.426Z" fill="#216EF0"/>
				<path class="fill-theme" fill-rule="evenodd" clip-rule="evenodd" d="M388 188C385.791 188 384 189.825 384 192.076V237.925C384 240.175 385.791 242 388 242H434C436.209 242 438 240.175 438 237.925V192.076C438 189.825 436.209 188 434 188H388ZM404.471 206.424C403.906 205.859 402.989 205.859 402.424 206.424C401.859 206.989 401.859 207.906 402.424 208.471L408.953 215L402.424 221.529C401.859 222.094 401.859 223.01 402.424 223.576C402.989 224.141 403.906 224.141 404.471 223.576L411 217.047L417.529 223.576C418.094 224.141 419.011 224.141 419.576 223.576C420.141 223.011 420.141 222.094 419.576 221.529L413.047 215L419.576 208.471C420.141 207.906 420.141 206.99 419.576 206.424C419.011 205.859 418.094 205.859 417.529 206.424L411 212.953L404.471 206.424Z" fill="#216EF0"/>
				</svg>
			</div>
		</div>
		<div class="col-md-6 col-sm-12 col-xs-12">
			<div class="wrapper right_unfound_block t404">
				<div style="font-size: 50px;line-height: 82px;color: #333333;">Ошибка 404</div>
				<div style="font-size: 22px;line-height: 36px;color: #333333;margin: -3px 0 14px;">Страница не найдена</div>
				<div style="font-size: 15px;line-height: 23px;color: #555555;">Возможно адрес набран неправильно или такой<br />страницы не существует</div>
				<div class="flex_wrapper">
												<a href="http://igc-aircon.com/dealer/" class="btn btn-default btn-lg">
								<svg xmlns="http://www.w3.org/2000/svg" width="6" height="12" viewBox="0 0 6 12" fill="none">
									<path d="M0.151531 5.46705C0.174841 5.43057 0.200841 5.39565 0.22953 5.36265L4.66229 0.263992C4.96831 -0.0879973 5.46447 -0.0879972 5.77049 0.263992C6.0765 0.615981 6.0765 1.18667 5.77049 1.53866L1.89179 6.00001L5.77047 10.4613C6.07649 10.8133 6.07649 11.384 5.77047 11.736C5.46445 12.088 4.96829 12.088 4.66228 11.736L0.229513 6.63735C-0.023451 6.34638 -0.0673059 5.90598 0.0979447 5.5632C0.113866 5.53017 0.131728 5.49805 0.151531 5.46705Z" fill="white"/>
								</svg>
								Вернуться назад
							</a>
											<a href="/">Перейти на главную</a>
				</div>
			</div>
		</div>
	</div>
</div>
<script>

/* plaxify start */
$('.d1').plaxify({"xRange":10,"yRange":10});
$('.d2').plaxify({"xRange":20,"yRange":10});
$('.d3').plaxify({"xRange":20,"yRange":10});
$.plax.enable({ "activityTarget": $('.body .container')});
/* plaxify end */

$(window).resize(function(){ //  BX.addCustomEvent('onWindowResize', function(eventdata) {
	try{
		var windowHeight = $(window).outerHeight();
		var panelHeight = $('#panel').outerHeight();
		var headerHeight = $('header').outerHeight();
		var footerHeight = $('footer').outerHeight();
		var mainPaddingTop = parseInt($('.main').css('padding-top'));
		var mainPaddingBottom = parseInt($('.main').css('padding-bottom'));
		var bodyMarginTop = parseInt($('.body').css('margin-top'));
		var bodyMarginBottom = parseInt($('.body').css('margin-bottom'));
		var page404Height = $('.page404').outerHeight();
		var part = Math.floor((windowHeight - panelHeight - headerHeight - footerHeight - page404Height) / 2);
		console.log(part);
		if(part < (mainPaddingTop + bodyMarginTop)){
			part = mainPaddingTop + bodyMarginTop;
		}
		if(part < (mainPaddingBottom + bodyMarginBottom)){
			part = mainPaddingBottom + bodyMarginBottom;
		}
		console.log(part);
		var top = (part - mainPaddingTop - bodyMarginTop);
		if(top < 0){
			top = 0;
		}
		var bottom = (part - mainPaddingBottom - bodyMarginBottom);
		if(bottom < 0){
			bottom = 0;
		}
		ignoreResize.push(true);
		$('.page404').css({'opacity': '1'});
		// $('.page404').css({'opacity': '1', 'margin-top': top + 'px', 'margin-bottom': bottom + 'px'});
		setTimeout(function() {
			$('.page404').css({'transition': 'none', '-moz-transition': 'none', '-ms-transition': 'none', '-o-transition': 'none', '-webkit-transition': 'none'});
		}, 400);
		ignoreResize.pop();
	}
	catch(e){}
});
</script>
																																														</div>
																						</div>													</div>									</div>							</div>		</div>				<section class="ctm-footer">
    <section class="ctm-footer-inner">
        <section class="ctm-footer-container">
            <article class="ctm-footer-box">
                <img class="ctm-footer-logo" src="/local/templates/centino-heat_s2/images/img-logo.png" alt="igc">
                <span class="ctm-footer-slogan">Бытовые и&nbsp;промышленные <br>климатические системы</span>
            </article>
            <article class="ctm-footer-box ctm-footer-box--callback-clone">
                <span class="btn btn-default" data-event="jqm" data-param-id="55" data-name="callback">Заказать звонок</span>
                <section class="ctm-footer-socials ctm-footer-socials--clone">
                            <a class="ctm-footer-social-link" href="https://vk.com/igcaircon">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/icon-vk.svg" alt="vk">
                            </a>
                            <a class="ctm-footer-social-link" href="https://www.youtube.com/channel/UCEU_d9DAPexWdPNLd8cSlYA">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/icon-youtube.svg" alt="youtube">
                            </a>							
                            <a class="ctm-footer-social-link" href="https://t.me/igcaircon">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/tg.svg" alt="vk">
                            </a>
                            <a class="ctm-footer-social-link" href="https://ok.ru/igcaircon">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ok.svg" alt="vk">
                            </a>
                            <a class="ctm-footer-social-link" href="https://igcaircon.clients.site/">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ya-biz.svg" alt="vk">
                            </a>
                            <a class="ctm-footer-social-link" href="https://zen.yandex.ru/id/6229b31acbc61a17d6b94825">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ya-zen.svg" alt="vk">
                            </a>
                </section>
            </article>
            <article class="ctm-footer-box">
                <section class="ctm-footer-menus">
                    

    <article class="ctm-footer-menu">
        <span class="ctm-footer-menu__name">
        <a class="ctm-footer-menu__link" href="/company/">
            Компания</a>
    </span>
            <ul class="ctm-footer-menu__list">


    <li class="ctm-footer-menu__list-item">
        <a class="ctm-footer-menu__link" href="/company/index.php">О компании</a>
    </li>


    <li class="ctm-footer-menu__list-item">
        <a class="ctm-footer-menu__link" href="/company/history/">История</a>
    </li>


    <li class="ctm-footer-menu__list-item">
        <a class="ctm-footer-menu__link" href="/company/partners/">Партнёры</a>
    </li>


    <li class="ctm-footer-menu__list-item">
        <a class="ctm-footer-menu__link" href="/company/reviews/">Отзывы</a>
    </li>


    <li class="ctm-footer-menu__list-item">
        <a class="ctm-footer-menu__link" href="/company/vacancy/">Вакансии</a>
    </li>


    <li class="ctm-footer-menu__list-item">
        <a class="ctm-footer-menu__link" href="/dealer/">Стать партнером</a>
    </li>


    </ul>
    </article>
                    

    <article class="ctm-footer-menu">
        <span class="ctm-footer-menu__name">
        <a class="ctm-footer-menu__link" href="/product/">
            Каталог</a>
    </span>
            <ul class="ctm-footer-menu__list">


    <li class="ctm-footer-menu__list-item">
        <a class="ctm-footer-menu__link" href="/product/bytovye_split_sistemy/">Бытовые сплит-системы</a>
    </li>


    <li class="ctm-footer-menu__list-item">
        <a class="ctm-footer-menu__link" href="/product/multizonalnye_vrf_sistemy/">Мультизональные VRF-системы</a>
    </li>


    <li class="ctm-footer-menu__list-item">
        <a class="ctm-footer-menu__link" href="/product/promyshlennye_konditsionery/">Промышленные кондиционеры</a>
    </li>


    <li class="ctm-footer-menu__list-item">
        <a class="ctm-footer-menu__link" href="/product/polupromyshlennye_konditsionery/">Полупромышленные кондиционеры</a>
    </li>


    </ul>
    </article>
                    <article class="ctm-footer-menu ctm-footer-menu--between">
                        <ul class="ctm-footer-menu__list">
                            <li class="ctm-footer-menu__list-item">
                                <span class="ctm-footer-menu__name">
                                    <a class="ctm-footer-menu__link" href="https://www.informteh.ru/services/">Услуги</a>
                                </span>
                            </li>
                            <li class="ctm-footer-menu__list-item">
                                <span class="ctm-footer-menu__name">
                                    <a class="ctm-footer-menu__link" href="/projects/">Наши проекты</a>
                                </span>
                            </li>
                            <li class="ctm-footer-menu__list-item">
                                <span class="ctm-footer-menu__name">
                                    <a class="ctm-footer-menu__link" href="/gde-kupit/">Где купить</a>
                                </span>
                            </li>
                        </ul>
                        <ul class="ctm-footer-menu__list">
                            <li class="ctm-footer-menu__list-item">
                                <span class="ctm-footer-menu__name">
                                    <a class="ctm-footer-menu__link" href="/contacts/">Контакты</a>
                                </span>
                            </li>
                        </ul>
                    </article>
                    <article class="ctm-footer-menu ctm-footer-menu--between">
                        <ul class="ctm-footer-menu__list">
                            <li class="ctm-footer-menu__list-item">
                                <span class="ctm-footer-menu__name">
                                <a class="ctm-footer-menu__link" href="/dealer/">Стать дилером</a>
                                </span>
                            </li>
                            <li class="ctm-footer-menu__list-item">
                                <span class="ctm-footer-menu__name">
                                    <a class="ctm-footer-menu__link" href="/press/">Новости</a>
                                </span>
                            </li>
                            <li class="ctm-footer-menu__list-item">
                                <span class="ctm-footer-menu__name">
                                    <a class="ctm-footer-menu__link" href="/podderzhka/dokumentatsiya/">Поддержка</a>
                                </span>
                            </li>
                        </ul>
                        <ul class="ctm-footer-menu__list">
                            <li class="ctm-footer-menu__list-item">
                                <span class="ctm-footer-hashtag">#igcaircon</span>
                            </li>
                        </ul>
                    </article>
                </section>
            </article>
        </section>
        <section class="ctm-footer-container">
            <article class="ctm-footer-box ctm-footer-box--callback">
                <span class="btn btn-default" data-event="jqm" data-param-id="55" data-name="callback">Заказать звонок</span>
            </article>
            <article class="ctm-footer-box">
                <section class="ctm-footer-menus">
                    <article class="ctm-footer-menu">
                        <a class="ctm-footer-contact" href="mailto:info@igc-aircon.com">
                            <svg class="ctm-footer-contact__icon" width="16" height="13" viewBox="0 0 16 13">
                                <path d="M14,13H2a2,2,0,0,1-2-2V2A2,2,0,0,1,2,0H14a2,2,0,0,1,2,2v9A2,2,0,0,1,14,13ZM3.534,2L8.015,6.482,12.5,2H3.534ZM14,3.5L8.827,8.671a1.047,1.047,0,0,1-.812.3,1.047,1.047,0,0,1-.811-0.3L2,3.467V11H14V3.5Z"></path>
                            </svg>info@igc-aircon.com
                        </a>
                    </article>
                    <article class="ctm-footer-menu">
                        <span class="ctm-footer-contact">
                            <svg class="ctm-footer-contact__icon" width="12" height="15" viewBox="0 0 12 15" fill="none">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M6 0C7.5913 0 9.1174 0.632144 10.2426 1.75736C11.3678 2.88258 12 4.4087 12 6C12 9.314 6 15 6 15C6 15 0 9.314 0 6C0 4.4087 0.632167 2.88258 1.75739 1.75736C2.8826 0.632144 4.4087 0 6 0ZM6 2C7.06087 2 8.07828 2.42142 8.82843 3.17157C9.57858 3.92172 10 4.93913 10 6C10 8.209 6 12.568 6 12.568C6 12.568 2 8.209 2 6C2 4.93913 2.42142 3.92172 3.17157 3.17157C3.92172 2.42142 4.93913 2 6 2Z" fill="#216EF0"></path>
                            </svg>Москва, ш. Энтузиастов, д. 17
                        </span>
                    </article>
                    <article class="ctm-footer-menu">
                        <a class="ctm-footer-contact ctm-footer-contact--underline" href="tel:+7 (495) 212-07-22">
                            <svg class="ctm-footer-contact__icon" width="12" height="15" viewBox="0 0 12 15" fill="none">
                                <path d="M7 9H5V11H7V9Z" fill="#35ABEF"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M0 2C0 0.895447 0.895386 0 2 0H10C11.1046 0 12 0.895447 12 2V13C12 14.1046 11.1046 15 10 15H2C0.895386 15 0 14.1046 0 13V2ZM2 2H10V13H2V2Z" fill="#35ABEF"></path></svg>+7 (495) 212-07-22
                        </a>
                    </article>
                    <article class="ctm-footer-menu">
                        <section class="ctm-footer-socials">
                            <a class="ctm-footer-social-link" href="https://vk.com/igcaircon">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/icon-vk.svg" alt="vk">
                            </a>
                            <a class="ctm-footer-social-link" href="https://www.youtube.com/channel/UCEU_d9DAPexWdPNLd8cSlYA">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/icon-youtube.svg" alt="youtube">
                            </a>							
                            <a class="ctm-footer-social-link" href="https://t.me/igcaircon">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/tg.svg" alt="vk">
                            </a>
                            <a class="ctm-footer-social-link" href="https://ok.ru/igcaircon">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ok.svg" alt="vk">
                            </a>
                            <a class="ctm-footer-social-link" href="https://igcaircon.clients.site/">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ya-biz.svg" alt="vk">
                            </a>
                            <a class="ctm-footer-social-link" href="https://zen.yandex.ru/id/6229b31acbc61a17d6b94825">
                                <img class="ctm-footer-social-link__img" src="/local/templates/centino-heat_s2/images/socials/ya-zen.svg" alt="vk">
                            </a>

                            							
                        </section>
                    </article>
                </section>
                <a class="ctm-footer-scroll-to-top ctm-footer-scroll-to-top--clone" href="#"></a>
            </article>
        </section>
    </section>
    <section class="ctm-footer-copyright">
        <a class="ctm-footer-scroll-to-top" href="#"></a>
        <span class="ctm-footer-copyright__label">&copy; 2020 Все права защищены.</span>
    </section>
</section>		<div class="bx_areas">
			<script>(window.Image ? (new Image()) : document.createElement('img')).src ='https://vk.com/rtrg?p=VK-RTRG-129423-csIVc';</script>

<!-- Global site tag (gtag.js) - Google Analytics -->

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-166641308-2"></script>

<script>

  window.dataLayer = window.dataLayer || [];

  function gtag(){dataLayer.push(arguments);}

  gtag('js', new Date());

 

  gtag('config', 'UA-166641308-2');

</script>	
	<!-- Facebook Pixel Code -->
<!--
	<script>
	!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
	n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
	n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
	t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
	document,'script','https://connect.facebook.net/en_US/fbevents.js');
	fbq('init', '730331250509062'); // Insert your pixel ID here.
	fbq('track', 'PageView');
	</script>
	<noscript><img height="1" width="1" style="display:none"
	src="https://www.facebook.com/tr?id=730331250509062&ev=PageView&noscript=1"
	/></noscript>
-->
	<!-- DO NOT MODIFY -->
	<!-- End Facebook Pixel Code --> 
<!--	
	<script>
	 (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	 (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	 m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	 })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	 ga('create', 'UA-97706499-3', 'auto');
	 ga('send', 'pageview');

	</script>
-->
<!-- Yandex.Metrika counter -->
<script >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(65658076, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/65658076" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

		<script>
                    (function(w, d, u, i, o, s, p) {
                        if (d.getElementById(i)) { return; } w['MangoObject'] = o;
                        w[o] = w[o] || function() { (w[o].q = w[o].q || []).push(arguments) }; w[o].u = u; w[o].t = 1 * new Date();
                        s = d.createElement('script'); s.async = 1; s.id = i; s.src = u; s.charset = 'utf-8';
                        p = d.getElementsByTagName('script')[0]; p.parentNode.insertBefore(s, p);
                    }(window, document, '//widgets.mango-office.ru/widgets/mango.js', 'mango-js', 'mgo'));
                    mgo({multichannel: {id: 8321}});
                </script>		</div>
				

	<div class="inline-search-block fixed with-close big">
		<div class="maxwidth-theme">
			<div class="col-md-12">
				<div class="search-wrapper">
					<div id="title-search">
						<form action="/search/" class="search">
							<div class="search-input-div">
								<input class="search-input" id="title-search-input" type="text" name="q" value="" placeholder="Найти" size="40" maxlength="50" autocomplete="off" />
							</div>
							<div class="search-button-div">
								<button class="btn btn-search btn-default bold btn-lg" type="submit" name="s" value="Найти">Найти</button>
								<span class="close-block inline-search-hide"><span class="svg svg-close close-icons"></span></span>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
<script>
	var jsControl = new JCTitleSearch2({
		//'WAIT_IMAGE': '/bitrix/themes/.default/images/wait.gif',
		'AJAX_PAGE' : '/bitrix/js/ui/polyfill/closest/js/closest.js',
		'CONTAINER_ID': 'title-search',
		'INPUT_ID': 'title-search-input',
		'MIN_QUERY_LEN': 2
	});
</script>				<!-- noindex -->
	<div class="ajax_basket">
		<!--'start_frame_cache_cHdneX'--><div class="basket fly">
	<div class="wrap cont">
		<span class="opener has_right_dok" title="Корзина пуста">
			<i class="svg inline  svg-inline-basket" aria-hidden="true" ><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M3.9542 11.1512L3.09069 5.57338L0.19159 1.58929C-0.133491 1.14253 -0.0349407 0.516785 0.41177 0.191607C0.858481 -0.133509 1.48422 -0.0349485 1.8093 0.411874L4.4152 3.99286H16.9612C17.0874 3.98798 17.2166 4.00709 17.3425 4.05307C17.7318 4.19524 17.9792 4.55388 17.9987 4.9433C18.0002 4.97322 18.0004 5.00332 17.9992 5.03355C17.9946 5.15239 17.9691 5.26585 17.9264 5.37052L15.7471 11.3393C15.596 11.7529 15.2009 12.0068 14.7838 11.9969H5.00222C4.96143 11.9994 4.92101 11.9994 4.88108 11.9969H4.77984V11.9855C4.36488 11.9171 4.02209 11.5896 3.9542 11.1512ZM5.80015 9.99592H14.1075L15.5688 5.99388H5.18052L5.80015 9.99592Z" fill="#888888"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M6.49537 18C7.87666 18 8.99637 16.8802 8.99637 15.4987C8.99637 14.1173 7.87666 12.9975 6.49537 12.9975C5.11408 12.9975 3.99437 14.1173 3.99437 15.4987C3.99437 16.8802 5.11408 18 6.49537 18ZM6.49537 15.999C6.7716 15.999 6.99557 15.775 6.99557 15.4987C6.99557 15.2225 6.7716 14.9985 6.49537 14.9985C6.21914 14.9985 5.99517 15.2225 5.99517 15.4987C5.99517 15.775 6.21914 15.999 6.49537 15.999Z" fill="#888888"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M13.4982 18C14.8794 18 15.9992 16.8802 15.9992 15.4987C15.9992 14.1173 14.8794 12.9975 13.4982 12.9975C12.1169 12.9975 10.9972 14.1173 10.9972 15.4987C10.9972 16.8802 12.1169 18 13.4982 18ZM13.4982 15.999C13.7744 15.999 13.9984 15.775 13.9984 15.4987C13.9984 15.2225 13.7744 14.9985 13.4982 14.9985C13.2219 14.9985 12.998 15.2225 12.998 15.4987C12.998 15.775 13.2219 15.999 13.4982 15.999Z" fill="#888888"/>
</svg>
</i>			<span class="count empted">0</span>
		</span>
							<div class="right_dok">
									<span class="link" title="Заказать звонок">
						<span class="animate-load" data-event="jqm" data-param-id="55" data-name="callback"><i class="svg inline  svg-inline-call" aria-hidden="true" ><svg width="17" height="24" viewBox="0 0 17 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6 8C5.44727 8 5 8.44727 5 9V13C5 13.5527 5.44727 14 6 14H10C10.333 14 10.6279 13.8379 10.8096 13.5879C10.9297 13.4229 11 13.2197 11 13C11 12.4473 10.5527 12 10 12H8.44531L12.6299 7.81543C13.0205 7.4248 13.0205 6.79199 12.6299 6.40137C12.2393 6.01074 11.6064 6.01074 11.2158 6.40137L7 10.6172V9C7 8.44727 6.55273 8 6 8Z" fill="#969BA4"/>
<path fill-rule="evenodd" clip-rule="evenodd" d="M1 0C0.447266 0 0 0.447266 0 1V23C0 23.2725 0.108398 23.5186 0.28418 23.6992C0.46582 23.8848 0.719727 24 1 24H16C16.2949 24 16.5596 23.873 16.7422 23.6709C16.9023 23.4932 17 23.2578 17 23V1C17 0.447266 16.5527 0 16 0H1ZM15 2H2V17H15V2ZM2 22V19H15V22H2Z" fill="#969BA4"/>
</svg>
</i></span>
					</span>
								<span class="link" title="Задать вопрос">
					<span class="animate-load" data-event="jqm" data-param-id="54" data-name="question"><i class="svg inline  svg-inline-ask" aria-hidden="true" ><svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M17.707 4.29297C17.8945 4.48047 18 4.73535 18 5V5.45801L21.5 7.47852C21.8096 7.65723 22 7.9873 22 8.34473V19C22 20.0264 21.4844 20.9326 20.6982 21.4736C20.2158 21.8057 19.6309 22 19 22H11H3C1.34277 22 0 20.6572 0 19V8.34473C0 8.1582 0.0517578 7.97949 0.144531 7.82617C0.230469 7.68457 0.351562 7.56445 0.5 7.47852L4 5.45801V1C4 0.912109 4.01172 0.827148 4.0332 0.746094C4.05078 0.677734 4.07617 0.612305 4.10645 0.551758C4.12109 0.522461 4.13672 0.494141 4.1543 0.466797C4.19922 0.395508 4.25293 0.330078 4.31445 0.272461C4.40527 0.186523 4.51172 0.117188 4.62988 0.0703125C4.69043 0.046875 4.75391 0.0283203 4.82031 0.0166016C4.87891 0.00585938 4.93848 0 5 0H13C13.2646 0 13.5195 0.105469 13.707 0.292969L17.707 4.29297ZM4 7.76758L2.5 8.63379C2.30176 8.74805 2.15234 8.92383 2.07031 9.12988C2.02441 9.24609 2 9.37109 2 9.5V9.57715L4 10.8262V7.76758ZM6 12.0742V2H12.5859L16 5.41406V12.0742L11 15.1963L6 12.0742ZM18 10.8262L20 9.57715V9.5C20 9.43262 19.9932 9.36621 19.9805 9.30176C19.9688 9.24316 19.9512 9.18555 19.9297 9.12988C19.8477 8.92383 19.6982 8.74805 19.5 8.63379L18 7.76758V10.8262ZM19 20H11H3C2.79785 20 2.61035 19.9404 2.45312 19.8379C2.42285 19.8174 2.39355 19.7959 2.36523 19.7725L2.30566 19.7188L2.26855 19.6816C2.18652 19.5947 2.12109 19.4932 2.0752 19.3809C2.02637 19.2637 2 19.1348 2 19V11.8867L11 17.5059L20 11.8867V19C20 19.0781 19.9912 19.1543 19.9746 19.2285C19.9619 19.2812 19.9453 19.332 19.9248 19.3809C19.8789 19.4932 19.8135 19.5947 19.7314 19.6816C19.6768 19.7412 19.6143 19.793 19.5469 19.8379C19.502 19.8672 19.4541 19.8936 19.4043 19.915C19.3721 19.9297 19.3379 19.9424 19.3037 19.9531L19.252 19.9678C19.1719 19.9893 19.0869 20 19 20ZM8 6C8 5.44727 8.44727 5 9 5H11C11.5527 5 12 5.44727 12 6C12 6.55273 11.5527 7 11 7H9C8.44727 7 8 6.55273 8 6ZM9 8C8.44727 8 8 8.44727 8 9C8 9.55273 8.44727 10 9 10H13C13.2822 10 13.5371 9.88281 13.7197 9.69531C13.8936 9.51562 14 9.27051 14 9C14 8.44727 13.5527 8 13 8H9Z" fill="#969BA4"/>
</svg>
</i></span>
				</span>
			</div>
					<h4>Корзина</h4>
		<svg class="flyBasketCloseBtn fill-theme-hover" onclick="$(this).closest('.ajax_basket').toggleClass('opened');" xmlns="http://www.w3.org/2000/svg" width="46" height="46" viewBox="0 0 46 46" fill="none">
			<circle cx="23" cy="23" r="23" fill="white"/>
			<path d="M28.6561 17.3431C28.2655 16.9525 27.6324 16.9525 27.2419 17.3431L22.9991 21.5858L18.7564 17.3431C18.3659 16.9526 17.7327 16.9526 17.3422 17.3431C16.9517 17.7336 16.9517 18.3668 17.3422 18.7573L21.5849 23L17.3424 27.2426C16.9518 27.6331 16.9518 28.2662 17.3424 28.6568C17.7329 29.0473 18.366 29.0473 18.7566 28.6568L22.9991 24.4142L27.2417 28.6568C27.6322 29.0473 28.2654 29.0473 28.6559 28.6568C29.0464 28.2663 29.0464 27.6331 28.6559 27.2426L24.4133 23L28.6561 18.7573C29.0466 18.3668 29.0466 17.7336 28.6561 17.3431Z" fill="#333"/>
		</svg>
				<div class="basket_empty">
			<div class="wrap">
				<h4>Ваша корзина пуста</h4>
				<div class="description">Исправить это просто: выберите в каталоге интересующий товар и нажмите кнопку «В корзину»</div>
				<div class="button"><a class="btn btn-default" href="/product/">В каталог</a></div>
			</div>
		</div>
	</div>
</div>
<!--'end_frame_cache_cHdneX'-->		</div>
	<!-- /noindex -->
				<script>
function checkLeftMenuFilter() {
	var el1 = $(".left_block > .left_menu_1");
	var el2 = $(".left_block > .sidearea > .bx_filter");
	if(el1.length > 0 || el2.length > 0) {
		if(el1.length == 0) {
			$(".ctm-mobile-control--menu").hide();
		}
		if(el2.length == 0) {
			$(".ctm-mobile-control--filter").hide();
		}
		$(".mobile-catalog-filter").show();
	}
}

$( document ).ready(function(){
	checkLeftMenuFilter();
	$('.ctm-mobile-control--menu').on('click', function(e){
		e.preventDefault();
		$(".mobile-catalog-filter").hide();
		$(".mobile-catalog-filter-close").show();
		$(".mobile-catalog-filter-titles").show();
		$("#custom-catalog-title").show();
		$('.left_block > .left_menu_1').show('fast');
		return false;
	});
	$('.ctm-mobile-control--filter').on('click', function(e){
		e.preventDefault();
		$(".mobile-catalog-filter").hide();
		$(".mobile-catalog-filter-close").show();
		$(".mobile-catalog-filter-titles").show();
		$("#custom-catalog-filter").show();
		$('.left_block > .sidearea > .bx_filter').show('fast');
		return false;
	});
	$('.ctm-mobile-control--close').on('click', function(e){
		e.preventDefault();
		$(".mobile-catalog-filter-titles").hide();
		$("#custom-catalog-title").hide();
		$("#custom-catalog-filter").hide();
		$('.left_block > .left_menu_1').hide();
		$('.left_block > .sidearea > .bx_filter').hide();
		$(".mobile-catalog-filter-close").hide();
		$(".mobile-catalog-filter").show();
		return false;
	});
});
</script>
	</body>
</html>